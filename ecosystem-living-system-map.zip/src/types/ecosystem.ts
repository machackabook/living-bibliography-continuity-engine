export type NodeType =
  | 'code_module'
  | 'package'
  | 'ai_model'
  | 'computation'
  | 'business_entity'
  | 'dataset';

export type EdgeType =
  | 'depends_on'
  | 'implements'
  | 'invokes'
  | 'produces'
  | 'verifies'
  | 'derives_from'
  | 'deployed_to'
  | 'owned_by'
  | 'licensed_under'
  | 'supersedes'
  | 'conflicts_with';

export type EdgeStatus = 'verified' | 'observing' | 'degraded' | 'conflict' | 'deprecated';

export interface EdgeTelemetry {
  latencyMs?: number;
  throughputRps?: number;
  callCount24h?: number;
  errorRatePercent?: number;
  dataTransferredMb?: number;
  lastObservedIso: string;
}

export interface ObservableEdge {
  id: string;
  sourceId: string;
  targetId: string;
  type: EdgeType;
  label: string;
  description: string;
  status: EdgeStatus;
  telemetry?: EdgeTelemetry;
  evidenceId?: string;
  evidenceHash?: string;
  versionConstraint?: string;
  conflictDetails?: string;
}

export interface TestCase {
  id: string;
  name: string;
  status: 'passed' | 'failed' | 'skipped';
  durationMs: number;
  assertionCount: number;
  evidenceProof?: string;
}

export interface TestSuiteResult {
  suiteName: string;
  totalTests: number;
  passedCount: number;
  failedCount: number;
  coveragePercent: number;
  fuzzIterations: number;
  cases: TestCase[];
  lastRunTimestamp: string;
  environment: string;
}

export interface SourceSymbol {
  name: string;
  kind: 'function' | 'class' | 'interface' | 'type' | 'constant';
  signature: string;
  visibility: 'exported' | 'internal' | 'protected';
  docString: string;
}

export interface SourceCodeDetails {
  primaryFile: string;
  language: string;
  linesOfCode: number;
  astComplexityScore: number;
  rawCode: string;
  exportedSymbols: SourceSymbol[];
  repositoryUrl: string;
  commitSha: string;
}

export interface FunctionalityCapability {
  title: string;
  description: string;
  slaCommitment?: string;
  stabilityTier: 'stable' | 'beta' | 'experimental';
  contractSpec: string;
}

export interface EvidenceReceipt {
  receiptId: string;
  experimentId: string;
  timestamp: string;
  sha256Proof: string;
  verifierEntity: string;
  signature: string;
  empiricalMetric: string;
  verifiedResult: string;
}

export interface OwnershipGovernance {
  owningEntityId: string;
  leadArchitect: string;
  contactEmail: string;
  tier: 'tier-1-mission-critical' | 'tier-2-core' | 'tier-3-supporting';
  deploymentTargets: string[];
  licenseSpdx: string;
  complianceCertified: boolean;
}

export interface EcosystemNode {
  id: string;
  name: string;
  type: NodeType;
  subsystem: string;
  version: string;
  description: string;
  healthScore: number; // 0-100
  status: 'operational' | 'verifying' | 'degraded' | 'deprecated';
  tags: string[];

  // Deep details for expandable package view
  sourceCode: SourceCodeDetails;
  functionality: FunctionalityCapability[];
  testResults: TestSuiteResult;
  ownership: OwnershipGovernance;
  evidence: EvidenceReceipt[];

  // Graph layout coordinates
  x?: number;
  y?: number;
  vx?: number;
  vy?: number;
}

export interface ExperimentRun {
  id: string;
  title: string;
  hypothesis: string;
  author: string;
  timestamp: string;
  status: 'idle' | 'running' | 'completed' | 'failed';
  targetNodeIds: string[];
  affectedEdgeTypes: EdgeType[];
  steps: {
    name: string;
    description: string;
    status: 'pending' | 'running' | 'success' | 'failure';
    outputLog?: string;
  }[];
  resultingEvidence?: EvidenceReceipt;
}
