import React, { useState } from 'react';
import {
  EcosystemNode,
  ObservableEdge,
  SourceSymbol,
  FunctionalityCapability,
  TestCase,
  EvidenceReceipt,
  NodeType,
  EdgeType,
} from '../types/ecosystem';
import {
  Code,
  GitBranch,
  CheckCircle2,
  AlertTriangle,
  ShieldCheck,
  FileText,
  ExternalLink,
  Copy,
  Check,
  Terminal,
  Cpu,
  Boxes,
  Database,
  Building2,
  Sparkles,
  Zap,
  Activity,
  Layers,
  FlaskConical,
  X,
} from 'lucide-react';

interface PackageDrawerProps {
  node: EcosystemNode | null;
  allNodes: EcosystemNode[];
  allEdges: ObservableEdge[];
  onClose: () => void;
  onSelectNode: (node: EcosystemNode) => void;
  onLaunchExperiment: (targetNodeId: string) => void;
}

type TabType = 'source' | 'dependencies' | 'functionality' | 'tests' | 'ownership' | 'evidence';

export const PackageDrawer: React.FC<PackageDrawerProps> = ({
  node,
  allNodes,
  allEdges,
  onClose,
  onSelectNode,
  onLaunchExperiment,
}) => {
  const [activeTab, setActiveTab] = useState<TabType>('source');
  const [copiedSha, setCopiedSha] = useState(false);
  const [copiedCode, setCopiedCode] = useState(false);
  const [copiedHash, setCopiedHash] = useState<string | null>(null);

  if (!node) return null;

  // Filter edges connected to this node
  const outboundEdges = allEdges.filter((e) => e.sourceId === node.id);
  const inboundEdges = allEdges.filter((e) => e.targetId === node.id);
  const totalRelationships = outboundEdges.length + inboundEdges.length;

  const copyToClipboard = (text: string, type: 'sha' | 'code' | 'hash') => {
    navigator.clipboard?.writeText(text);
    if (type === 'sha') {
      setCopiedSha(true);
      setTimeout(() => setCopiedSha(false), 2000);
    } else if (type === 'code') {
      setCopiedCode(true);
      setTimeout(() => setCopiedCode(false), 2000);
    } else {
      setCopiedHash(text);
      setTimeout(() => setCopiedHash(null), 2000);
    }
  };

  const getNodeIcon = (type: NodeType) => {
    switch (type) {
      case 'package': return <Boxes className="w-4 h-4 text-sky-400" />;
      case 'code_module': return <Code className="w-4 h-4 text-emerald-400" />;
      case 'ai_model': return <Sparkles className="w-4 h-4 text-purple-400" />;
      case 'computation': return <Cpu className="w-4 h-4 text-amber-400" />;
      case 'dataset': return <Database className="w-4 h-4 text-pink-400" />;
      case 'business_entity': return <Building2 className="w-4 h-4 text-orange-400" />;
      default: return <Layers className="w-4 h-4 text-slate-400" />;
    }
  };

  const getEdgeBadgeColor = (type: EdgeType, status: string) => {
    if (status === 'conflict') return 'bg-rose-950/70 border-rose-600/70 text-rose-300';
    switch (type) {
      case 'depends_on': return 'bg-sky-950/60 border-sky-600/60 text-sky-300';
      case 'implements': return 'bg-emerald-950/60 border-emerald-600/60 text-emerald-300';
      case 'invokes': return 'bg-amber-950/60 border-amber-600/60 text-amber-300';
      case 'produces': return 'bg-purple-950/60 border-purple-600/60 text-purple-300';
      case 'verifies': return 'bg-lime-950/60 border-lime-600/60 text-lime-300';
      case 'derives_from': return 'bg-indigo-950/60 border-indigo-600/60 text-indigo-300';
      case 'deployed_to': return 'bg-cyan-950/60 border-cyan-600/60 text-cyan-300';
      case 'owned_by': return 'bg-pink-950/60 border-pink-600/60 text-pink-300';
      case 'licensed_under': return 'bg-slate-900 border-slate-700 text-slate-300';
      case 'supersedes': return 'bg-orange-950/60 border-orange-600/60 text-orange-300';
      case 'conflicts_with': return 'bg-rose-950/80 border-rose-500 text-rose-300';
      default: return 'bg-slate-800 border-slate-700 text-slate-300';
    }
  };

  return (
    <aside
      className="fixed top-0 right-0 h-full w-full sm:w-[560px] md:w-[640px] lg:w-[680px] bg-[#0c1017]/95 backdrop-blur-xl border-l border-slate-800 shadow-2xl z-40 flex flex-col transition-transform duration-300 text-slate-200"
      aria-label="Package Details Drawer"
    >
      {/* Top Header */}
      <div className="p-5 border-b border-slate-800/80 bg-gradient-to-r from-slate-900/90 to-slate-950/80">
        <div className="flex items-start justify-between gap-4">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap mb-1.5">
              <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-mono font-medium border border-slate-700 bg-slate-800/80">
                {getNodeIcon(node.type)}
                <span className="uppercase text-slate-300">{node.type.replace('_', ' ')}</span>
              </span>
              <span className="text-xs px-2 py-0.5 rounded bg-slate-800 text-slate-400 font-mono">
                {node.subsystem}
              </span>
              {node.version && (
                <span className="text-xs px-2 py-0.5 rounded bg-sky-950 text-sky-400 font-mono border border-sky-800/50">
                  v{node.version}
                </span>
              )}
            </div>

            <h2 className="text-xl font-bold font-mono tracking-tight text-white truncate flex items-center gap-2">
              {node.name}
            </h2>
            <p className="text-xs text-slate-400 mt-1 line-clamp-2 leading-relaxed">
              {node.description}
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => onLaunchExperiment(node.id)}
              className="px-2.5 py-1.5 rounded-md text-xs font-mono font-semibold bg-emerald-950 hover:bg-emerald-900 text-emerald-300 border border-emerald-700/60 flex items-center gap-1.5 transition-colors shadow-sm"
              title="Launch verification experiment for this node"
            >
              <FlaskConical className="w-3.5 h-3.5 text-emerald-400" />
              <span>Experiment</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-md hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
              aria-label="Close drawer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Health & Verification Bar */}
        <div className="mt-4 pt-3 border-t border-slate-800/60 flex items-center justify-between text-xs">
          <div className="flex items-center gap-3">
            <span className="text-slate-400">Health Score:</span>
            <div className="flex items-center gap-1.5">
              <div className="w-24 h-2 bg-slate-800 rounded-full overflow-hidden">
                <div
                  className={`h-full rounded-full ${
                    node.healthScore >= 90
                      ? 'bg-emerald-500'
                      : node.healthScore >= 70
                      ? 'bg-amber-500'
                      : 'bg-rose-500'
                  }`}
                  style={{ width: `${node.healthScore}%` }}
                />
              </div>
              <span className="font-mono font-bold text-white">{node.healthScore}%</span>
            </div>
          </div>

          <div className="flex items-center gap-4 text-xs font-mono text-slate-400">
            <span>Status: <span className="text-emerald-400 uppercase font-semibold">{node.status}</span></span>
            <span>Relationships: <span className="text-sky-400 font-semibold">{totalRelationships}</span></span>
            <span>Evidence: <span className="text-lime-400 font-semibold">{node.evidence?.length || 0} receipts</span></span>
          </div>
        </div>

        {/* Navigation Tabs */}
        <nav className="flex space-x-1 mt-4 overflow-x-auto pb-1 border-b border-slate-800" aria-label="Package sections">
          {[
            { id: 'source', label: 'Source', icon: Code, badge: `${node.sourceCode.linesOfCode} LOC` },
            { id: 'dependencies', label: 'Dependencies', icon: GitBranch, badge: totalRelationships },
            { id: 'functionality', label: 'Functionality', icon: Zap, badge: node.functionality.length },
            { id: 'tests', label: 'Test Results', icon: CheckCircle2, badge: `${node.testResults.coveragePercent}%` },
            { id: 'ownership', label: 'Ownership', icon: ShieldCheck },
            { id: 'evidence', label: 'Evidence', icon: FlaskConical, badge: node.evidence.length },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as TabType)}
                className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md whitespace-nowrap transition-colors ${
                  isActive
                    ? 'bg-slate-800 text-white border border-slate-700 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-sky-400' : 'text-slate-500'}`} />
                <span>{tab.label}</span>
                {tab.badge !== undefined && (
                  <span
                    className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono ${
                      isActive ? 'bg-sky-950 text-sky-300' : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    {tab.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Drawer Body - Scrollable */}
      <div className="flex-1 overflow-y-auto p-5 space-y-6">
        {/* ===================================================================
            TAB 1: SOURCE CODE
           =================================================================== */}
        {activeTab === 'source' && (
          <div className="space-y-5">
            {/* Source Metadata Banner */}
            <div className="bg-slate-900/80 rounded-lg p-3.5 border border-slate-800 text-xs font-mono space-y-2">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <span className="text-slate-400">Primary File:</span>
                <span className="text-sky-300 bg-sky-950/60 px-2 py-0.5 rounded border border-sky-800/40">
                  {node.sourceCode.primaryFile}
                </span>
              </div>
              <div className="flex items-center justify-between flex-wrap gap-2">
                <span className="text-slate-400">Language / Runtime:</span>
                <span className="text-emerald-300">{node.sourceCode.language}</span>
              </div>
              <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-800">
                <div>
                  <span className="text-slate-500">Lines of Code: </span>
                  <span className="text-white font-bold">{node.sourceCode.linesOfCode.toLocaleString()}</span>
                </div>
                <div>
                  <span className="text-slate-500">AST Complexity: </span>
                  <span className="text-amber-400 font-bold">{node.sourceCode.astComplexityScore} / 10.0</span>
                </div>
              </div>
              <div className="flex items-center justify-between pt-2 border-t border-slate-800">
                <span className="text-slate-500">Git Commit:</span>
                <div className="flex items-center gap-1.5">
                  <span className="text-slate-300 font-mono">{node.sourceCode.commitSha.slice(0, 9)}</span>
                  <button
                    onClick={() => copyToClipboard(node.sourceCode.commitSha, 'sha')}
                    className="p-1 hover:bg-slate-800 rounded text-slate-400 hover:text-white"
                    title="Copy full commit SHA"
                  >
                    {copiedSha ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                  <a
                    href={node.sourceCode.repositoryUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="p-1 hover:bg-slate-800 rounded text-slate-400 hover:text-sky-400"
                    title="Open repository"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>
            </div>

            {/* Raw Code View */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-mono uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                  <Code className="w-3.5 h-3.5 text-sky-400" />
                  Source Implementation
                </span>
                <button
                  onClick={() => copyToClipboard(node.sourceCode.rawCode, 'code')}
                  className="text-xs font-mono text-slate-400 hover:text-white flex items-center gap-1 px-2 py-0.5 rounded bg-slate-800/80 border border-slate-700/60"
                >
                  {copiedCode ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  <span>{copiedCode ? 'Copied' : 'Copy Code'}</span>
                </button>
              </div>

              <div className="relative rounded-lg bg-[#080b11] border border-slate-800/90 font-mono text-xs overflow-x-auto p-4 text-slate-300 leading-relaxed shadow-inner">
                <pre>{node.sourceCode.rawCode}</pre>
              </div>
            </div>

            {/* Exported Symbols */}
            <div>
              <h3 className="text-xs font-mono uppercase tracking-wider text-slate-400 mb-2 flex items-center gap-1.5">
                <Boxes className="w-3.5 h-3.5 text-emerald-400" />
                Exported Interface &amp; AST Symbols ({node.sourceCode.exportedSymbols.length})
              </h3>
              <div className="space-y-2">
                {node.sourceCode.exportedSymbols.map((sym: SourceSymbol, i: number) => (
                  <div key={i} className="bg-slate-900/60 p-3 rounded-lg border border-slate-800/80 space-y-1">
                    <div className="flex items-center justify-between gap-2 flex-wrap">
                      <span className="font-mono font-semibold text-sky-300 text-xs">{sym.name}</span>
                      <div className="flex items-center gap-1.5 text-[11px] font-mono">
                        <span className="px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                          {sym.kind}
                        </span>
                        <span className="px-1.5 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800/50">
                          {sym.visibility}
                        </span>
                      </div>
                    </div>
                    <div className="font-mono text-[11px] text-slate-400 bg-slate-950/60 p-1.5 rounded border border-slate-800">
                      {sym.signature}
                    </div>
                    <p className="text-xs text-slate-400 leading-snug">{sym.docString}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ===================================================================
            TAB 2: DEPENDENCIES & TYPED EDGES
           =================================================================== */}
        {activeTab === 'dependencies' && (
          <div className="space-y-6">
            <div className="p-3 bg-slate-900/60 rounded-lg border border-slate-800 text-xs text-slate-300 leading-relaxed">
              <span className="text-amber-400 font-semibold">Every edge is an observable relationship.</span> Connections are verified empirically through telemetry, contract tests, and cryptographic proofs rather than static assertions.
            </div>

            {/* Outbound Relationships */}
            <div>
              <h3 className="text-xs font-mono uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-1.5">
                <GitBranch className="w-3.5 h-3.5 text-sky-400" />
                Outbound Observable Edges ({outboundEdges.length})
              </h3>
              {outboundEdges.length === 0 ? (
                <div className="text-xs text-slate-500 italic p-3 bg-slate-900/30 rounded border border-slate-800/50">
                  No outbound relationships recorded.
                </div>
              ) : (
                <div className="space-y-2.5">
                  {outboundEdges.map((edge) => {
                    const targetNode = allNodes.find((n) => n.id === edge.targetId);
                    return (
                      <div
                        key={edge.id}
                        className={`p-3.5 rounded-lg border bg-slate-900/80 transition-all hover:border-slate-600 ${
                          edge.type === 'conflicts_with' ? 'border-rose-700/80 bg-rose-950/20' : 'border-slate-800'
                        }`}
                      >
                        <div className="flex items-center justify-between gap-2 flex-wrap mb-2">
                          <span className={`px-2 py-0.5 text-xs font-mono font-semibold rounded border ${getEdgeBadgeColor(edge.type, edge.status)}`}>
                            {edge.type}
                          </span>
                          <span className={`text-[11px] font-mono px-2 py-0.5 rounded ${
                            edge.status === 'verified'
                              ? 'bg-emerald-950 text-emerald-400 border border-emerald-800/50'
                              : edge.status === 'conflict'
                              ? 'bg-rose-950 text-rose-300 border border-rose-700 font-bold animate-pulse'
                              : 'bg-slate-800 text-slate-400'
                          }`}>
                            {edge.status.toUpperCase()}
                          </span>
                        </div>

                        <div className="flex items-center justify-between gap-2">
                          <button
                            onClick={() => targetNode && onSelectNode(targetNode)}
                            className="font-mono text-sm font-semibold text-white hover:text-sky-300 flex items-center gap-1.5 group text-left"
                          >
                            <span>→ {targetNode ? targetNode.name : edge.targetId}</span>
                            <span className="text-[11px] text-slate-500 font-normal">({targetNode?.type})</span>
                          </button>
                          {edge.versionConstraint && (
                            <span className="text-xs font-mono text-slate-400 bg-slate-800 px-1.5 py-0.5 rounded">
                              {edge.versionConstraint}
                            </span>
                          )}
                        </div>

                        <p className="text-xs text-slate-400 mt-1.5">{edge.description}</p>

                        {/* Conflict Notice & Resolution Trigger */}
                        {edge.conflictDetails && (
                          <div className="mt-2.5 p-2 bg-rose-950/40 border border-rose-800/60 rounded text-xs text-rose-300 space-y-1.5">
                            <div className="flex items-center gap-1.5 font-semibold text-rose-400">
                              <AlertTriangle className="w-3.5 h-3.5" />
                              <span>Observed Conflict:</span>
                            </div>
                            <p>{edge.conflictDetails}</p>
                            <button
                              onClick={() => onLaunchExperiment('exp-resolve-conflict-enclave')}
                              className="mt-1 px-2 py-1 rounded bg-rose-900/60 hover:bg-rose-800 border border-rose-600 text-rose-200 text-xs font-mono font-medium flex items-center gap-1.5 transition-colors"
                            >
                              <FlaskConical className="w-3.5 h-3.5 text-rose-300" />
                              <span>Run Conflict Resolution Experiment</span>
                            </button>
                          </div>
                        )}

                        {/* Telemetry Stats */}
                        {edge.telemetry && (
                          <div className="mt-2.5 pt-2 border-t border-slate-800/80 grid grid-cols-2 sm:grid-cols-3 gap-2 text-[11px] font-mono text-slate-400">
                            {edge.telemetry.latencyMs !== undefined && (
                              <div>Latency: <span className="text-sky-400 font-bold">{edge.telemetry.latencyMs}ms</span></div>
                            )}
                            {edge.telemetry.throughputRps !== undefined && (
                              <div>Throughput: <span className="text-emerald-400 font-bold">{edge.telemetry.throughputRps} rps</span></div>
                            )}
                            {edge.telemetry.errorRatePercent !== undefined && (
                              <div>Error Rate: <span className={`${edge.telemetry.errorRatePercent > 0 ? 'text-rose-400 font-bold' : 'text-slate-300'}`}>{edge.telemetry.errorRatePercent}%</span></div>
                            )}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Inbound Relationships */}
            <div>
              <h3 className="text-xs font-mono uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-1.5">
                <GitBranch className="w-3.5 h-3.5 text-emerald-400 rotate-180" />
                Inbound Observable Edges ({inboundEdges.length})
              </h3>
              {inboundEdges.length === 0 ? (
                <div className="text-xs text-slate-500 italic p-3 bg-slate-900/30 rounded border border-slate-800/50">
                  No inbound relationships recorded.
                </div>
              ) : (
                <div className="space-y-2.5">
                  {inboundEdges.map((edge) => {
                    const sourceNode = allNodes.find((n) => n.id === edge.sourceId);
                    return (
                      <div
                        key={edge.id}
                        className="p-3.5 rounded-lg border border-slate-800 bg-slate-900/80 transition-all hover:border-slate-600"
                      >
                        <div className="flex items-center justify-between gap-2 flex-wrap mb-2">
                          <span className={`px-2 py-0.5 text-xs font-mono font-semibold rounded border ${getEdgeBadgeColor(edge.type, edge.status)}`}>
                            {edge.type}
                          </span>
                          <span className="text-[11px] font-mono text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded border border-emerald-800/50">
                            {edge.status.toUpperCase()}
                          </span>
                        </div>

                        <button
                          onClick={() => sourceNode && onSelectNode(sourceNode)}
                          className="font-mono text-sm font-semibold text-white hover:text-emerald-300 flex items-center gap-1.5 group text-left"
                        >
                          <span>← {sourceNode ? sourceNode.name : edge.sourceId}</span>
                          <span className="text-[11px] text-slate-500 font-normal">({sourceNode?.type})</span>
                        </button>
                        <p className="text-xs text-slate-400 mt-1">{edge.description}</p>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        )}

        {/* ===================================================================
            TAB 3: FUNCTIONALITY & CONTRACTS
           =================================================================== */}
        {activeTab === 'functionality' && (
          <div className="space-y-4">
            <h3 className="text-xs font-mono uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-amber-400" />
              Declared Capabilities &amp; SLA Specifications ({node.functionality.length})
            </h3>

            {node.functionality.map((fn: FunctionalityCapability, idx: number) => (
              <div key={idx} className="bg-slate-900/70 p-4 rounded-lg border border-slate-800 space-y-2.5">
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <h4 className="font-semibold text-white text-sm flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-amber-400" />
                    {fn.title}
                  </h4>
                  <span className={`text-[11px] font-mono px-2 py-0.5 rounded font-medium ${
                    fn.stabilityTier === 'stable'
                      ? 'bg-emerald-950 text-emerald-300 border border-emerald-800/50'
                      : fn.stabilityTier === 'beta'
                      ? 'bg-amber-950 text-amber-300 border border-amber-800/50'
                      : 'bg-purple-950 text-purple-300 border border-purple-800/50'
                  }`}>
                    {fn.stabilityTier.toUpperCase()}
                  </span>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed">{fn.description}</p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-2 border-t border-slate-800/80 text-xs font-mono">
                  {fn.slaCommitment && (
                    <div className="bg-slate-950/60 p-2 rounded border border-slate-800">
                      <span className="text-slate-500 block text-[10px] uppercase">SLA Commitment</span>
                      <span className="text-amber-300 font-bold">{fn.slaCommitment}</span>
                    </div>
                  )}
                  {fn.contractSpec && (
                    <div className="bg-slate-950/60 p-2 rounded border border-slate-800">
                      <span className="text-slate-500 block text-[10px] uppercase">Contract Standard</span>
                      <span className="text-sky-300">{fn.contractSpec}</span>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* ===================================================================
            TAB 4: TEST RESULTS & COVERAGE
           =================================================================== */}
        {activeTab === 'tests' && (
          <div className="space-y-5">
            {/* Test Suite Summary Header */}
            <div className="bg-slate-900/80 p-4 rounded-lg border border-slate-800 space-y-3">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <div>
                  <h4 className="font-semibold text-white text-sm">{node.testResults.suiteName}</h4>
                  <p className="text-xs text-slate-400 mt-0.5">Env: {node.testResults.environment}</p>
                </div>
                <div className="text-right font-mono">
                  <span className="text-xs text-slate-400">Coverage: </span>
                  <span className="text-emerald-400 font-bold text-sm">{node.testResults.coveragePercent}%</span>
                </div>
              </div>

              {/* Progress bar */}
              <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden flex">
                <div
                  className="bg-emerald-500 h-full"
                  style={{ width: `${(node.testResults.passedCount / (node.testResults.totalTests || 1)) * 100}%` }}
                />
                {node.testResults.failedCount > 0 && (
                  <div
                    className="bg-rose-500 h-full"
                    style={{ width: `${(node.testResults.failedCount / (node.testResults.totalTests || 1)) * 100}%` }}
                  />
                )}
              </div>

              <div className="grid grid-cols-3 gap-2 text-center text-xs font-mono pt-1">
                <div className="bg-slate-950/60 p-2 rounded border border-slate-800">
                  <span className="text-slate-500 block text-[10px]">TOTAL</span>
                  <span className="text-white font-bold">{node.testResults.totalTests}</span>
                </div>
                <div className="bg-slate-950/60 p-2 rounded border border-slate-800">
                  <span className="text-slate-500 block text-[10px]">PASSED</span>
                  <span className="text-emerald-400 font-bold">{node.testResults.passedCount}</span>
                </div>
                <div className="bg-slate-950/60 p-2 rounded border border-slate-800">
                  <span className="text-slate-500 block text-[10px]">FUZZ ITERATIONS</span>
                  <span className="text-sky-400 font-bold">{node.testResults.fuzzIterations.toLocaleString()}</span>
                </div>
              </div>

              <div className="text-[11px] font-mono text-slate-500 text-right">
                Last verified: {new Date(node.testResults.lastRunTimestamp).toUTCString()}
              </div>
            </div>

            {/* Test Case Breakdown */}
            <div>
              <h4 className="text-xs font-mono uppercase tracking-wider text-slate-400 mb-2 flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                Granular Test Cases ({node.testResults.cases.length})
              </h4>
              <div className="space-y-2">
                {node.testResults.cases.map((t: TestCase) => (
                  <div
                    key={t.id}
                    className="bg-slate-900/60 p-3 rounded-lg border border-slate-800/80 flex items-center justify-between gap-3 text-xs font-mono"
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                      <span className="text-slate-200 truncate">{t.name}</span>
                    </div>
                    <div className="flex items-center gap-3 shrink-0 text-slate-400 text-[11px]">
                      <span>{t.assertionCount.toLocaleString()} asserts</span>
                      <span className="text-sky-400 font-bold">{t.durationMs}ms</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ===================================================================
            TAB 5: OWNERSHIP & GOVERNANCE
           =================================================================== */}
        {activeTab === 'ownership' && (
          <div className="space-y-4">
            <div className="bg-slate-900/80 p-4 rounded-lg border border-slate-800 space-y-3.5 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Owning Business Entity:</span>
                <span className="text-sky-300 font-mono font-semibold bg-sky-950/60 px-2.5 py-1 rounded border border-sky-800/40">
                  {node.ownership.owningEntityId}
                </span>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-slate-400">Lead Architect:</span>
                <span className="text-white font-medium">{node.ownership.leadArchitect}</span>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-slate-400">Contact Email:</span>
                <span className="text-slate-300 font-mono">{node.ownership.contactEmail}</span>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-slate-400">Tier Classification:</span>
                <span className="font-mono text-amber-300 uppercase px-2 py-0.5 rounded bg-amber-950/60 border border-amber-800/50">
                  {node.ownership.tier.replace(/-/g, ' ')}
                </span>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-slate-400">License (SPDX):</span>
                <span className="font-mono text-emerald-400 font-bold bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800/50">
                  {node.ownership.licenseSpdx}
                </span>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-slate-400">Compliance Audit:</span>
                <span className="font-mono text-emerald-400 flex items-center gap-1 font-bold">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  CERTIFIED COMPLIANT
                </span>
              </div>

              <div className="pt-2 border-t border-slate-800">
                <span className="text-slate-400 block mb-1.5 font-mono">Deployment Targets:</span>
                <div className="space-y-1">
                  {node.ownership.deploymentTargets.map((target: string, idx: number) => (
                    <div key={idx} className="bg-slate-950/60 p-2 rounded font-mono text-[11px] text-slate-300 border border-slate-800">
                      • {target}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ===================================================================
            TAB 6: EVIDENCE & EXPERIMENT PROOFS
           =================================================================== */}
        {activeTab === 'evidence' && (
          <div className="space-y-5">
            {/* The Loop Closes Through Experiments Motto */}
            <div className="p-3.5 bg-sky-950/40 rounded-lg border border-sky-800/50 text-xs text-sky-200 leading-relaxed">
              <span className="font-bold text-white block mb-1">Empirical Provenance Principle:</span>
              "The loop closes through new experiments, not by allowing a visualization to silently rewrite its own source of truth."
            </div>

            <div className="flex items-center justify-between">
              <h3 className="text-xs font-mono uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-lime-400" />
                Immutable Evidence Receipts ({node.evidence.length})
              </h3>
              <button
                onClick={() => onLaunchExperiment(node.id)}
                className="px-2.5 py-1 text-xs font-mono font-medium rounded bg-emerald-950 hover:bg-emerald-900 text-emerald-300 border border-emerald-700/60 flex items-center gap-1"
              >
                <FlaskConical className="w-3 h-3 text-emerald-400" />
                <span>Run New Experiment</span>
              </button>
            </div>

            {node.evidence.length === 0 ? (
              <div className="text-xs text-slate-400 italic p-4 bg-slate-900/40 rounded-lg border border-slate-800 text-center">
                No receipts minted for this node yet. Launch an experiment to mint verified empirical evidence.
              </div>
            ) : (
              <div className="space-y-3">
                {node.evidence.map((rcpt: EvidenceReceipt) => (
                  <div key={rcpt.receiptId} className="bg-slate-900/80 p-4 rounded-lg border border-slate-800 space-y-2.5 text-xs font-mono">
                    <div className="flex items-center justify-between flex-wrap gap-2">
                      <span className="font-bold text-emerald-400 text-sm">{rcpt.receiptId}</span>
                      <span className="text-[11px] text-slate-400 bg-slate-800 px-2 py-0.5 rounded">
                        Exp: {rcpt.experimentId}
                      </span>
                    </div>

                    <div className="space-y-1 text-slate-300">
                      <div>
                        <span className="text-slate-500">Metric: </span>
                        <span className="text-white font-medium">{rcpt.empiricalMetric}</span>
                      </div>
                      <div>
                        <span className="text-slate-500">Result: </span>
                        <span className="text-lime-300">{rcpt.verifiedResult}</span>
                      </div>
                      <div>
                        <span className="text-slate-500">Verifier: </span>
                        <span className="text-sky-300">{rcpt.verifierEntity}</span>
                      </div>
                    </div>

                    {/* SHA256 Hash */}
                    <div className="pt-2 border-t border-slate-800/80">
                      <span className="text-[10px] text-slate-500 uppercase block mb-1">SHA-256 Merkle Proof</span>
                      <div className="flex items-center justify-between gap-2 bg-slate-950/80 p-1.5 rounded border border-slate-800 text-[11px]">
                        <span className="truncate text-slate-400 font-mono">{rcpt.sha256Proof}</span>
                        <button
                          onClick={() => copyToClipboard(rcpt.sha256Proof, 'hash')}
                          className="p-1 hover:bg-slate-800 rounded text-slate-400 hover:text-white shrink-0"
                          title="Copy SHA-256 hash"
                        >
                          {copiedHash === rcpt.sha256Proof ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                        </button>
                      </div>
                    </div>

                    <div className="text-[10px] text-slate-500 flex items-center justify-between pt-1">
                      <span>Sig: {rcpt.signature}</span>
                      <span>{new Date(rcpt.timestamp).toUTCString()}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </aside>
  );
};
