import React, { useState, useEffect, useMemo, useCallback } from 'react';
import {
  EcosystemNode,
  ObservableEdge,
  ExperimentRun,
  EvidenceReceipt,
  NodeType,
  EdgeType,
} from './types/ecosystem';
import {
  INITIAL_NODES,
  INITIAL_EDGES,
  INITIAL_EXPERIMENTS,
} from './data/ecosystemData';
import { LivingSystemGraph } from './components/LivingSystemGraph';
import { PackageDrawer } from './components/PackageDrawer';
import { ExperimentModal } from './components/ExperimentModal';
import {
  Search,
  FlaskConical,
  RotateCcw,
  Eye,
  EyeOff,
  Layers,
  ShieldCheck,
  AlertTriangle,
  FileCheck,
  Check,
  GitBranch,
  Network,
  Maximize2,
  Minimize2,
  Compass,
  Cpu,
  Boxes,
  Code,
  Sparkles,
  Database,
  Building2,
  Filter,
} from 'lucide-react';

const ALL_NODE_TYPES: NodeType[] = [
  'package',
  'code_module',
  'ai_model',
  'computation',
  'business_entity',
  'dataset',
];

const ALL_EDGE_TYPES: EdgeType[] = [
  'depends_on',
  'implements',
  'invokes',
  'produces',
  'verifies',
  'derives_from',
  'deployed_to',
  'owned_by',
  'licensed_under',
  'supersedes',
  'conflicts_with',
];

export default function App() {
  const [nodes, setNodes] = useState<EcosystemNode[]>(INITIAL_NODES);
  const [edges, setEdges] = useState<ObservableEdge[]>(INITIAL_EDGES);
  const [experiments, setExperiments] = useState<ExperimentRun[]>(INITIAL_EXPERIMENTS);

  // Selection states
  const [selectedNodeId, setSelectedNodeId] = useState<string | null>(null);
  const [selectedEdgeId, setSelectedEdgeId] = useState<string | null>(null);

  // Camera presets
  const [cameraPreset, setCameraPreset] = useState<'player' | 'top' | 'side' | 'wide'>('wide');

  // Filter states
  const [activeNodeTypes, setActiveNodeTypes] = useState<Set<NodeType>>(new Set(ALL_NODE_TYPES));
  const [activeEdgeTypes, setActiveEdgeTypes] = useState<Set<EdgeType>>(new Set(ALL_EDGE_TYPES));
  const [conflictFocusOnly, setConflictFocusOnly] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');

  // UI Visibility
  const [isUiHidden, setIsUiHidden] = useState<boolean>(false);
  const [showFiltersModal, setShowFiltersModal] = useState<boolean>(false);

  // Experiment Modal
  const [isExperimentModalOpen, setIsExperimentModalOpen] = useState<boolean>(false);
  const [targetExperimentId, setTargetExperimentId] = useState<string | null>(null);

  // Notification Toast
  const [notification, setNotification] = useState<string | null>(null);

  // Keyboard shortcut listener for 'H'
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;
      if (e.key === 'h' || e.key === 'H') {
        setIsUiHidden((prev) => {
          const next = !prev;
          if (next) {
            document.body.classList.add('cinematic-ui-hidden');
          } else {
            document.body.classList.remove('cinematic-ui-hidden');
          }
          return next;
        });
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const triggerToast = (msg: string) => {
    setNotification(msg);
    setTimeout(() => setNotification(null), 4000);
  };

  // Toggle UI visibility
  const toggleUI = (force?: boolean) => {
    const next = force !== undefined ? force : !isUiHidden;
    setIsUiHidden(next);
    if (next) {
      document.body.classList.add('cinematic-ui-hidden');
    } else {
      document.body.classList.remove('cinematic-ui-hidden');
    }
  };

  // Selected Node Object
  const selectedNode = useMemo(() => {
    return nodes.find((n) => n.id === selectedNodeId) || null;
  }, [nodes, selectedNodeId]);

  // All collected evidence receipts for the captured tray
  const allEvidenceReceipts = useMemo(() => {
    const receipts: EvidenceReceipt[] = [];
    nodes.forEach((n) => {
      n.evidence?.forEach((r) => {
        if (!receipts.some((existing) => existing.receiptId === r.receiptId)) {
          receipts.push(r);
        }
      });
    });
    return receipts;
  }, [nodes]);

  // Toggle Node Type Filter
  const toggleNodeType = (type: NodeType) => {
    setActiveNodeTypes((prev) => {
      const next = new Set(prev);
      if (next.has(type)) {
        if (next.size > 1) next.delete(type);
      } else {
        next.add(type);
      }
      return next;
    });
  };

  // Toggle Edge Type Filter
  const toggleEdgeType = (type: EdgeType) => {
    setActiveEdgeTypes((prev) => {
      const next = new Set(prev);
      if (next.has(type)) {
        if (next.size > 1) next.delete(type);
      } else {
        next.add(type);
      }
      return next;
    });
  };

  // Side Toggle: Toggle between All Relationships and Conflict/Degraded Focus
  const handleSideToggle = () => {
    setConflictFocusOnly((prev) => {
      const next = !prev;
      if (next) {
        // Focus only on conflicts and their nodes
        setActiveEdgeTypes(new Set(['conflicts_with', 'verifies', 'depends_on']));
        triggerToast('Perspective: Focusing on Conflict Edges & Empirical Verifiers');
      } else {
        setActiveEdgeTypes(new Set(ALL_EDGE_TYPES));
        triggerToast('Perspective: Showing All 11 Typed Relationships');
      }
      return next;
    });
  };

  // Handle Experiment Completion (The loop closes through new experiments!)
  const handleCompleteExperiment = (
    experiment: ExperimentRun,
    receipt: EvidenceReceipt,
    resolvedEdgeId?: string,
    newEdge?: ObservableEdge
  ) => {
    // 1. Update Experiments List
    setExperiments((prev) =>
      prev.map((exp) =>
        exp.id === experiment.id
          ? {
              ...exp,
              status: 'completed',
              resultingEvidence: receipt,
            }
          : exp
      )
    );

    // 2. Attach newly minted receipt to target nodes
    setNodes((prevNodes) =>
      prevNodes.map((n) => {
        if (experiment.targetNodeIds.includes(n.id)) {
          const updatedReceipts = [receipt, ...(n.evidence || [])];
          return {
            ...n,
            healthScore: Math.min(100, n.healthScore + 2),
            status: 'operational',
            evidence: updatedReceipts,
          };
        }
        return n;
      })
    );

    // 3. If resolving a conflict edge
    if (resolvedEdgeId && newEdge) {
      setEdges((prevEdges) => {
        const filtered = prevEdges.filter((e) => e.id !== resolvedEdgeId);
        return [...filtered, newEdge];
      });
      triggerToast(
        `Resolved conflict edge! Minted receipt ${receipt.receiptId}. Updated Living System Map.`
      );
    } else {
      triggerToast(`Verification complete! Minted empirical evidence receipt ${receipt.receiptId}.`);
    }
  };

  // Reset Physics & Camera View
  const handleReset = () => {
    setCameraPreset('wide');
    setSelectedNodeId(null);
    setSelectedEdgeId(null);
    setSearchQuery('');
    setActiveNodeTypes(new Set(ALL_NODE_TYPES));
    setActiveEdgeTypes(new Set(ALL_EDGE_TYPES));
    setConflictFocusOnly(false);
    triggerToast('Reset living graph layout and camera transform to default');
  };

  // Launch experiment for specific node or experiment
  const handleLaunchExperiment = (targetId: string) => {
    // If targetId is an experiment ID
    if (targetId.startsWith('exp-')) {
      setTargetExperimentId(targetId);
    } else {
      // Find matching experiment or default to enclave conflict resolver
      const exp = experiments.find((e) => e.targetNodeIds.includes(targetId));
      setTargetExperimentId(exp ? exp.id : 'exp-resolve-conflict-enclave');
    }
    setIsExperimentModalOpen(true);
  };

  // Filtered edges respecting conflictFocusOnly
  const displayedEdges = useMemo(() => {
    if (!conflictFocusOnly) return edges;
    return edges.filter((e) => e.type === 'conflicts_with' || e.type === 'verifies');
  }, [edges, conflictFocusOnly]);

  const conflictCount = useMemo(() => {
    return edges.filter((e) => e.type === 'conflicts_with').length;
  }, [edges]);

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-[#0a0d14] text-slate-100 font-sans select-none">
      {/* 2D Canvas Graph Container */}
      <div id="canvas-container" className="absolute inset-0 z-0">
        <LivingSystemGraph
          nodes={nodes}
          edges={displayedEdges}
          selectedNodeId={selectedNodeId}
          onSelectNode={(node) => {
            setSelectedNodeId(node.id);
            setSelectedEdgeId(null);
          }}
          selectedEdgeId={selectedEdgeId}
          onSelectEdge={(edge) => {
            setSelectedEdgeId(edge ? edge.id : null);
          }}
          filteredNodeTypes={activeNodeTypes}
          filteredEdgeTypes={activeEdgeTypes}
          cameraPreset={cameraPreset}
          searchQuery={searchQuery}
        />
      </div>

      {/* Floating Restore UI button for mobile / hidden UI */}
      <button
        type="button"
        className="hud-btn"
        id="btn-mobile-show-ui"
        onClick={() => toggleUI(false)}
        title="Show HUD Controls"
      >
        <Eye className="w-4 h-4 text-sky-400" />
        <span>Show UI [H]</span>
      </button>

      {/* ===================================================================
          TOP HUD (Header, Search, Metric Pills, and Action Buttons)
         =================================================================== */}
      <header
        id="hud-top"
        className="fixed top-3 left-4 right-4 z-20 flex items-center justify-between gap-3 pointer-events-none flex-wrap"
      >
        {/* Left: Brand Pill & Living System Map Metrics */}
        <div className="hud-group pointer-events-auto flex items-center gap-2.5 flex-wrap">
          <div className="bg-slate-900/90 backdrop-blur-md border border-slate-700/80 px-3.5 py-1.5 rounded-lg flex items-center gap-2.5 shadow-xl">
            <div className="p-1.5 rounded bg-sky-950 border border-sky-800 text-sky-400">
              <Network className="w-4 h-4" />
            </div>
            <div>
              <div className="text-xs font-bold font-mono text-white tracking-wider uppercase flex items-center gap-1.5">
                <span>Living System Map</span>
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              </div>
              <div className="text-[10px] text-slate-400 font-mono">
                {nodes.length} Nodes • {edges.length} Typed Edges • {allEvidenceReceipts.length} Proofs
              </div>
            </div>
          </div>

          {/* Conflict Alert Pill */}
          {conflictCount > 0 && (
            <button
              onClick={handleSideToggle}
              className="bg-rose-950/80 hover:bg-rose-900 border border-rose-600/80 px-2.5 py-1.5 rounded-lg flex items-center gap-1.5 text-xs font-mono font-semibold text-rose-300 shadow-lg transition-all animate-pulse"
              title="Click to isolate conflicts in the system map"
            >
              <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
              <span>{conflictCount} Conflict Detected</span>
            </button>
          )}

          {/* Search Bar */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Filter nodes or packages..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-slate-900/80 backdrop-blur-md border border-slate-700 text-xs text-white pl-8 pr-3 py-1.5 rounded-lg focus:outline-none focus:border-sky-500 font-mono w-44 md:w-56 placeholder-slate-500"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white text-xs"
              >
                ✕
              </button>
            )}
          </div>
        </div>

        {/* Right: Actions, Camera Presets, and Test Required Controls */}
        <div className="hud-group pointer-events-auto flex items-center gap-2 flex-wrap">
          {/* Action 1: Required ID btn-side-toggle */}
          <button
            className={`hud-btn ${conflictFocusOnly ? 'active danger' : ''}`}
            id="btn-side-toggle"
            onClick={handleSideToggle}
            title="Toggle Perspective: Focus Conflict Edges vs All Observable Relationships"
          >
            <GitBranch className="w-3.5 h-3.5 text-amber-400" />
            <span>{conflictFocusOnly ? 'Focus: Conflicts' : 'Perspective: All'}</span>
          </button>

          {/* Action 2: Required ID btn-ai-move */}
          <button
            className="hud-btn success"
            id="btn-ai-move"
            onClick={() => handleLaunchExperiment('exp-resolve-conflict-enclave')}
            title="Execute Automated Experiment to Close Empirical Verification Loop"
          >
            <FlaskConical className="w-3.5 h-3.5 text-emerald-400" />
            <span>Run Experiment</span>
          </button>

          {/* Action 3: Required ID btn-reset */}
          <button
            className="hud-btn"
            id="btn-reset"
            onClick={handleReset}
            title="Reset layout physics and camera orientation"
          >
            <RotateCcw className="w-3.5 h-3.5 text-slate-400" />
            <span>Reset Map</span>
          </button>

          {/* Camera Presets: Required IDs btn-cam-player, btn-cam-top, btn-cam-side, btn-cam-wide */}
          <div className="hidden sm:flex items-center bg-slate-900/80 backdrop-blur-md border border-slate-700 rounded-lg p-0.5">
            <button
              className={`hud-btn border-0 rounded ${cameraPreset === 'player' ? 'active' : ''}`}
              id="btn-cam-player"
              onClick={() => {
                setCameraPreset('player');
                triggerToast('Camera: Node Focus Zoom');
              }}
              title="Camera: Focused Node Close-Up"
            >
              Node
            </button>
            <button
              className={`hud-btn border-0 rounded ${cameraPreset === 'top' ? 'active' : ''}`}
              id="btn-cam-top"
              onClick={() => {
                setCameraPreset('top');
                triggerToast('Camera: Overhead Architecture Map');
              }}
              title="Camera: Overhead Architecture"
            >
              Arch
            </button>
            <button
              className={`hud-btn border-0 rounded ${cameraPreset === 'side' ? 'active' : ''}`}
              id="btn-cam-side"
              onClick={() => {
                setCameraPreset('side');
                triggerToast('Camera: Stratified Subsystem View');
              }}
              title="Camera: Stratified Layers"
            >
              Layers
            </button>
            <button
              className={`hud-btn border-0 rounded ${cameraPreset === 'wide' ? 'active' : ''}`}
              id="btn-cam-wide"
              onClick={() => {
                setCameraPreset('wide');
                triggerToast('Camera: Macro Ecosystem Panoramic');
              }}
              title="Camera: Wide Ecosystem"
            >
              Macro
            </button>
          </div>

          {/* Action: Hide UI - Required ID btn-hide-ui */}
          <button
            className="hud-btn"
            id="btn-hide-ui"
            onClick={() => toggleUI()}
            title="Toggle HUD visibility (Shortcut: H)"
          >
            <EyeOff className="w-3.5 h-3.5 text-slate-400" />
            <span>Hide UI [H]</span>
          </button>
        </div>
      </header>

      {/* ===================================================================
          FILTER BAR (Node & Edge Type Toggles)
         =================================================================== */}
      <div
        id="filter-bar"
        className="fixed top-16 left-4 z-20 pointer-events-auto flex flex-col gap-1.5 max-w-[94vw] overflow-x-auto pb-1"
      >
        {/* Node Types Pills */}
        <div className="flex items-center gap-1.5 flex-nowrap overflow-x-auto py-1">
          <span className="text-[10px] font-mono font-semibold uppercase text-slate-400 bg-slate-900/90 px-2 py-1 rounded border border-slate-800 shrink-0">
            Node Types:
          </span>
          {ALL_NODE_TYPES.map((type) => {
            const isActive = activeNodeTypes.has(type);
            return (
              <button
                key={type}
                onClick={() => toggleNodeType(type)}
                className={`px-2 py-0.5 rounded text-[11px] font-mono transition-all shrink-0 flex items-center gap-1 border ${
                  isActive
                    ? 'bg-slate-800 text-slate-200 border-slate-600 shadow-sm'
                    : 'bg-slate-950/60 text-slate-500 border-slate-800/80 opacity-60'
                }`}
              >
                <span
                  className={`w-1.5 h-1.5 rounded-full ${
                    type === 'package'
                      ? 'bg-sky-400'
                      : type === 'code_module'
                      ? 'bg-emerald-400'
                      : type === 'ai_model'
                      ? 'bg-purple-400'
                      : type === 'computation'
                      ? 'bg-amber-400'
                      : type === 'dataset'
                      ? 'bg-pink-400'
                      : 'bg-orange-400'
                  }`}
                />
                <span>{type.replace('_', ' ')}</span>
              </button>
            );
          })}
        </div>

        {/* Typed Edges Pills */}
        <div className="flex items-center gap-1.5 flex-nowrap overflow-x-auto py-0.5">
          <span className="text-[10px] font-mono font-semibold uppercase text-slate-400 bg-slate-900/90 px-2 py-1 rounded border border-slate-800 shrink-0">
            Relationships:
          </span>
          {ALL_EDGE_TYPES.map((type) => {
            const isActive = activeEdgeTypes.has(type);
            const isConflict = type === 'conflicts_with';
            return (
              <button
                key={type}
                onClick={() => toggleEdgeType(type)}
                className={`px-2 py-0.5 rounded text-[10px] font-mono transition-all shrink-0 flex items-center gap-1 border ${
                  isActive
                    ? isConflict
                      ? 'bg-rose-950/80 text-rose-300 border-rose-700'
                      : 'bg-slate-800/90 text-slate-300 border-slate-700'
                    : 'bg-slate-950/60 text-slate-500 border-slate-900 opacity-50'
                }`}
              >
                <span>{type}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* ===================================================================
          BOTTOM CAPTURED TRAY (Required ID captured-tray)
          Evidence Receipts Ledger backing observable truth
         =================================================================== */}
      <footer
        id="captured-tray"
        className="fixed bottom-10 left-4 right-4 z-20 pointer-events-auto flex items-center justify-between gap-3 bg-slate-900/90 backdrop-blur-md border border-slate-800 px-4 py-2.5 rounded-xl shadow-2xl text-xs overflow-x-auto"
      >
        <div className="flex items-center gap-2 shrink-0">
          <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
          <span className="font-mono font-bold text-white uppercase text-[11px] tracking-wider">
            Evidence Ledger:
          </span>
          <span className="text-[10px] font-mono text-slate-400 hidden sm:inline">
            "The loop closes through new experiments, not silent rewrites."
          </span>
        </div>

        {/* Horizontal Receipts Strip */}
        <div className="flex items-center gap-2 overflow-x-auto py-0.5">
          {allEvidenceReceipts.map((rcpt) => (
            <button
              key={rcpt.receiptId}
              onClick={() => {
                const targetNode = nodes.find((n) =>
                  n.evidence?.some((e) => e.receiptId === rcpt.receiptId)
                );
                if (targetNode) setSelectedNodeId(targetNode.id);
                triggerToast(`Inspecting Evidence Proof ${rcpt.receiptId}`);
              }}
              className="bg-slate-950/80 hover:bg-slate-800 border border-slate-800 hover:border-emerald-600 px-2.5 py-1 rounded-md text-[11px] font-mono flex items-center gap-1.5 transition-all shrink-0 text-slate-300"
              title={`Proof: ${rcpt.sha256Proof}\nMetric: ${rcpt.empiricalMetric}`}
            >
              <FileCheck className="w-3 h-3 text-emerald-400" />
              <span className="font-bold text-white">{rcpt.receiptId}</span>
              <span className="text-slate-500 truncate max-w-[120px]">{rcpt.empiricalMetric}</span>
            </button>
          ))}
        </div>

        <button
          onClick={() => setIsExperimentModalOpen(true)}
          className="shrink-0 px-2.5 py-1 rounded bg-emerald-950 hover:bg-emerald-900 text-emerald-300 border border-emerald-700/60 font-mono text-[11px] font-semibold flex items-center gap-1 shadow-sm transition-colors"
        >
          <FlaskConical className="w-3.5 h-3.5 text-emerald-400" />
          <span>New Experiment</span>
        </button>
      </footer>

      {/* ===================================================================
          CONTROLS HINT BANNER (Required ID controls-hint)
         =================================================================== */}
      <div
        id="controls-hint"
        className="fixed bottom-2 left-1/2 -translate-x-1/2 z-20 pointer-events-none text-center text-[10px] font-mono text-slate-400 bg-slate-950/80 backdrop-blur px-3 py-1 rounded-full border border-slate-800/80 whitespace-nowrap shadow"
      >
        Drag canvas to Pan • Scroll to Zoom • Drag nodes to reposition • Click any node to expand Source, Dependencies, Tests &amp; Evidence • [H] to toggle HUD
      </div>

      {/* Notification Toast */}
      {notification && (
        <div className="fixed top-24 left-1/2 -translate-x-1/2 z-50 bg-slate-900/95 border border-sky-500 text-sky-200 px-4 py-2 rounded-lg text-xs font-mono shadow-2xl flex items-center gap-2 animate-fade-in">
          <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
          <span>{notification}</span>
        </div>
      )}

      {/* Side Package Details Drawer */}
      <PackageDrawer
        node={selectedNode}
        allNodes={nodes}
        allEdges={edges}
        onClose={() => setSelectedNodeId(null)}
        onSelectNode={(node) => setSelectedNodeId(node.id)}
        onLaunchExperiment={(targetId) => handleLaunchExperiment(targetId)}
      />

      {/* Experiment Studio Modal */}
      <ExperimentModal
        isOpen={isExperimentModalOpen}
        onClose={() => setIsExperimentModalOpen(false)}
        experiments={experiments}
        nodes={nodes}
        edges={edges}
        onCompleteExperiment={handleCompleteExperiment}
        targetExperimentId={targetExperimentId}
      />
    </div>
  );
}
