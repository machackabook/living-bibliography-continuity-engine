import React, { useRef, useEffect, useState, useCallback } from 'react';
import { EcosystemNode, ObservableEdge, NodeType, EdgeType } from '../types/ecosystem';

interface LivingSystemGraphProps {
  nodes: EcosystemNode[];
  edges: ObservableEdge[];
  selectedNodeId: string | null;
  onSelectNode: (node: EcosystemNode) => void;
  selectedEdgeId: string | null;
  onSelectEdge: (edge: ObservableEdge | null) => void;
  filteredNodeTypes: Set<NodeType>;
  filteredEdgeTypes: Set<EdgeType>;
  cameraPreset: 'player' | 'top' | 'side' | 'wide';
  searchQuery: string;
}

export const LivingSystemGraph: React.FC<LivingSystemGraphProps> = ({
  nodes,
  edges,
  selectedNodeId,
  onSelectNode,
  selectedEdgeId,
  onSelectEdge,
  filteredNodeTypes,
  filteredEdgeTypes,
  cameraPreset,
  searchQuery,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Pan and Zoom
  const transformRef = useRef({ x: 0, y: 0, k: 1 });
  const isDraggingRef = useRef(false);
  const dragStartRef = useRef({ x: 0, y: 0 });
  const draggedNodeRef = useRef<EcosystemNode | null>(null);
  const hoveredNodeRef = useRef<EcosystemNode | null>(null);
  const hoveredEdgeRef = useRef<ObservableEdge | null>(null);

  // Node position simulation map
  const posMapRef = useRef<Map<string, { x: number; y: number; vx: number; vy: number }>>(new Map());
  const animationFrameIdRef = useRef<number>(0);
  const timeRef = useRef<number>(0);

  // Initialize node positions into subsystem clusters
  useEffect(() => {
    const clusterCenters: Record<string, { x: number; y: number }> = {
      'Core Concurrency Engine': { x: -280, y: -160 },
      'Neural Inference & Reasoning': { x: 260, y: -180 },
      'Graph & Observable Ontology': { x: -80, y: 140 },
      'Security & Cryptographic Audit': { x: 280, y: 160 },
      'Data & Benchmark Lineage': { x: 40, y: -260 },
      'Governance & Compliance': { x: -320, y: 180 },
    };

    nodes.forEach((node, idx) => {
      if (!posMapRef.current.has(node.id)) {
        const center = clusterCenters[node.subsystem] || { x: 0, y: 0 };
        const angle = (idx * 1.6180339887) % (Math.PI * 2);
        const radius = 60 + ((idx * 37) % 110);
        posMapRef.current.set(node.id, {
          x: center.x + Math.cos(angle) * radius,
          y: center.y + Math.sin(angle) * radius,
          vx: 0,
          vy: 0,
        });
      }
    });
  }, [nodes]);

  // Handle camera presets
  useEffect(() => {
    if (cameraPreset === 'wide') {
      transformRef.current = { x: 0, y: 0, k: 0.85 };
    } else if (cameraPreset === 'top') {
      transformRef.current = { x: 0, y: 0, k: 1.15 };
    } else if (cameraPreset === 'side') {
      // Stratified view
      transformRef.current = { x: -40, y: 0, k: 0.95 };
    } else if (cameraPreset === 'player') {
      if (selectedNodeId) {
        const pos = posMapRef.current.get(selectedNodeId);
        if (pos) {
          transformRef.current = { x: -pos.x * 1.4, y: -pos.y * 1.4, k: 1.4 };
        }
      } else {
        transformRef.current = { x: 0, y: 0, k: 1.0 };
      }
    }
  }, [cameraPreset, selectedNodeId]);

  // Node type styles
  const getNodeColor = (type: NodeType) => {
    switch (type) {
      case 'package': return '#38bdf8'; // Sky blue
      case 'code_module': return '#34d399'; // Emerald
      case 'ai_model': return '#c084fc'; // Purple
      case 'computation': return '#fbbf24'; // Amber
      case 'dataset': return '#f472b6'; // Rose
      case 'business_entity': return '#fb923c'; // Orange
      default: return '#94a3b8';
    }
  };

  // Edge type styles
  const getEdgeColor = (type: EdgeType, status: string) => {
    if (status === 'conflict') return '#f43f5e'; // Crimson
    switch (type) {
      case 'depends_on': return '#38bdf8';
      case 'implements': return '#34d399';
      case 'invokes': return '#fbbf24';
      case 'produces': return '#c084fc';
      case 'verifies': return '#a3e635';
      case 'derives_from': return '#818cf8';
      case 'deployed_to': return '#67e8f9';
      case 'owned_by': return '#f472b6';
      case 'licensed_under': return '#94a3b8';
      case 'supersedes': return '#fb923c';
      case 'conflicts_with': return '#f43f5e';
      default: return '#64748b';
    }
  };

  // Main canvas animation loop with physics simulation
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let isRunning = true;

    const render = () => {
      if (!isRunning) return;
      timeRef.current += 0.016;
      const t = timeRef.current;

      // Handle retina resolution
      const width = canvas.clientWidth;
      const height = canvas.clientHeight;
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      if (canvas.width !== width * dpr || canvas.height !== height * dpr) {
        canvas.width = width * dpr;
        canvas.height = height * dpr;
      }

      ctx.save();
      ctx.scale(dpr, dpr);
      ctx.clearRect(0, 0, width, height);

      // Background subtle grid
      const centerX = width / 2 + transformRef.current.x;
      const centerY = height / 2 + transformRef.current.y;
      const zoom = transformRef.current.k;

      ctx.fillStyle = '#0a0d14';
      ctx.fillRect(0, 0, width, height);

      // Grid lines
      const gridSize = 40 * zoom;
      const startX = (centerX % gridSize) - gridSize;
      const startY = (centerY % gridSize) - gridSize;

      ctx.strokeStyle = 'rgba(255, 255, 255, 0.025)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      for (let x = startX; x < width; x += gridSize) {
        ctx.moveTo(x, 0);
        ctx.lineTo(x, height);
      }
      for (let y = startY; y < height; y += gridSize) {
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
      }
      ctx.stroke();

      // Transform to world coordinates
      ctx.save();
      ctx.translate(centerX, centerY);
      ctx.scale(zoom, zoom);

      // Physics step: spring forces on edges & repulsion between nodes
      const activeNodes = nodes.filter((n) => filteredNodeTypes.has(n.type));
      const activeEdges = edges.filter(
        (e) =>
          filteredEdgeTypes.has(e.type) &&
          posMapRef.current.has(e.sourceId) &&
          posMapRef.current.has(e.targetId)
      );

      // Node Repulsion
      for (let i = 0; i < activeNodes.length; i++) {
        const nA = activeNodes[i];
        const pA = posMapRef.current.get(nA.id);
        if (!pA) continue;

        for (let j = i + 1; j < activeNodes.length; j++) {
          const nB = activeNodes[j];
          const pB = posMapRef.current.get(nB.id);
          if (!pB) continue;

          const dx = pB.x - pA.x;
          const dy = pB.y - pA.y;
          const distSq = dx * dx + dy * dy || 1;
          const dist = Math.sqrt(distSq);
          if (dist < 260) {
            const force = (260 - dist) / (dist * 18);
            if (draggedNodeRef.current?.id !== nA.id) {
              pA.vx -= dx * force * 0.04;
              pA.vy -= dy * force * 0.04;
            }
            if (draggedNodeRef.current?.id !== nB.id) {
              pB.vx += dx * force * 0.04;
              pB.vy += dy * force * 0.04;
            }
          }
        }
      }

      // Edge Springs
      for (const edge of activeEdges) {
        const pS = posMapRef.current.get(edge.sourceId);
        const pT = posMapRef.current.get(edge.targetId);
        if (!pS || !pT) continue;

        const dx = pT.x - pS.x;
        const dy = pT.y - pS.y;
        const dist = Math.hypot(dx, dy) || 1;
        const targetDist = edge.type === 'conflicts_with' ? 220 : 130;
        const springForce = (dist - targetDist) * 0.0035;

        if (draggedNodeRef.current?.id !== edge.sourceId) {
          pS.vx += (dx / dist) * springForce;
          pS.vy += (dy / dist) * springForce;
        }
        if (draggedNodeRef.current?.id !== edge.targetId) {
          pT.vx -= (dx / dist) * springForce;
          pT.vy -= (dy / dist) * springForce;
        }
      }

      // Apply damping & update node positions
      activeNodes.forEach((node) => {
        const p = posMapRef.current.get(node.id);
        if (!p) return;
        if (draggedNodeRef.current?.id !== node.id) {
          p.x += p.vx;
          p.y += p.vy;
          p.vx *= 0.88;
          p.vy *= 0.88;
        }
      });

      // Draw Subsystem Cluster Soft Halos
      const subsystems = Array.from(new Set(activeNodes.map((n) => n.subsystem)));
      subsystems.forEach((subsys) => {
        const clusterNodes = activeNodes.filter((n) => n.subsystem === subsys);
        if (clusterNodes.length === 0) return;

        let avgX = 0, avgY = 0;
        clusterNodes.forEach((n) => {
          const p = posMapRef.current.get(n.id);
          if (p) { avgX += p.x; avgY += p.y; }
        });
        avgX /= clusterNodes.length;
        avgY /= clusterNodes.length;

        // Radius encompassing cluster
        let maxR = 90;
        clusterNodes.forEach((n) => {
          const p = posMapRef.current.get(n.id);
          if (p) {
            const d = Math.hypot(p.x - avgX, p.y - avgY);
            if (d + 60 > maxR) maxR = d + 60;
          }
        });

        // Soft glow hull
        const grad = ctx.createRadialGradient(avgX, avgY, 10, avgX, avgY, maxR);
        grad.addColorStop(0.0, 'rgba(56, 189, 248, 0.06)');
        grad.addColorStop(0.7, 'rgba(56, 189, 248, 0.02)');
        grad.addColorStop(1.0, 'transparent');
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.arc(avgX, avgY, maxR, 0, Math.PI * 2);
        ctx.fill();

        // Cluster Subsystem label
        ctx.font = '11px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
        ctx.fillStyle = 'rgba(148, 163, 184, 0.45)';
        ctx.textAlign = 'center';
        ctx.fillText(subsys.toUpperCase(), avgX, avgY - maxR + 18);
      });

      // -----------------------------------------------------------------------
      // DRAW EDGES (Observable Typed Relationships)
      // -----------------------------------------------------------------------
      activeEdges.forEach((edge) => {
        const pS = posMapRef.current.get(edge.sourceId);
        const pT = posMapRef.current.get(edge.targetId);
        if (!pS || !pT) return;

        const isHovered = hoveredEdgeRef.current?.id === edge.id;
        const isSelected = selectedEdgeId === edge.id;
        const isSourceSelected = selectedNodeId === edge.sourceId;
        const isTargetSelected = selectedNodeId === edge.targetId;
        const isHighlight = isHovered || isSelected || isSourceSelected || isTargetSelected;

        const color = getEdgeColor(edge.type, edge.status);
        const isConflict = edge.type === 'conflicts_with';

        ctx.strokeStyle = color;
        ctx.lineWidth = isHighlight ? 2.8 : 1.4;
        ctx.globalAlpha = isHighlight ? 0.95 : selectedNodeId ? 0.22 : 0.65;

        // Curved spline
        const midX = (pS.x + pT.x) / 2;
        const midY = (pS.y + pT.y) / 2;
        const dx = pT.x - pS.x;
        const dy = pT.y - pS.y;
        const normX = -dy * 0.15;
        const normY = dx * 0.15;
        const cpX = midX + normX;
        const cpY = midY + normY;

        ctx.beginPath();
        if (isConflict) {
          ctx.setLineDash([6, 4]);
        } else {
          ctx.setLineDash([]);
        }
        ctx.moveTo(pS.x, pS.y);
        ctx.quadraticCurveTo(cpX, cpY, pT.x, pT.y);
        ctx.stroke();
        ctx.setLineDash([]);

        // Directional Arrowhead
        const arrowT = 0.68;
        const ax = (1 - arrowT) * (1 - arrowT) * pS.x + 2 * (1 - arrowT) * arrowT * cpX + arrowT * arrowT * pT.x;
        const ay = (1 - arrowT) * (1 - arrowT) * pS.y + 2 * (1 - arrowT) * arrowT * cpY + arrowT * arrowT * pT.y;
        const tangentX = 2 * (1 - arrowT) * (cpX - pS.x) + 2 * arrowT * (pT.x - cpX);
        const tangentY = 2 * (1 - arrowT) * (cpY - pS.y) + 2 * arrowT * (pT.y - cpY);
        const angle = Math.atan2(tangentY, tangentX);

        ctx.fillStyle = color;
        ctx.beginPath();
        ctx.moveTo(ax, ay);
        ctx.lineTo(ax - 9 * Math.cos(angle - Math.PI / 6), ay - 9 * Math.sin(angle - Math.PI / 6));
        ctx.lineTo(ax - 9 * Math.cos(angle + Math.PI / 6), ay - 9 * Math.sin(angle + Math.PI / 6));
        ctx.closePath();
        ctx.fill();

        // Animated telemetry pulse along 'invokes' and 'produces' edges
        if (edge.type === 'invokes' || edge.type === 'produces') {
          const pulsePhase = (t * 0.8 + (edge.id.length * 0.15)) % 1;
          const px = (1 - pulsePhase) * (1 - pulsePhase) * pS.x + 2 * (1 - pulsePhase) * pulsePhase * cpX + pulsePhase * pulsePhase * pT.x;
          const py = (1 - pulsePhase) * (1 - pulsePhase) * pS.y + 2 * (1 - pulsePhase) * pulsePhase * cpY + pulsePhase * pulsePhase * pT.y;

          ctx.fillStyle = '#ffffff';
          ctx.beginPath();
          ctx.arc(px, py, 3.2, 0, Math.PI * 2);
          ctx.fill();
        }

        // Edge Type Label pill on highlight or hover
        if (isHighlight || zoom > 1.25) {
          const labelX = (pS.x + pT.x) / 2 + normX * 0.6;
          const labelY = (pS.y + pT.y) / 2 + normY * 0.6;

          ctx.font = 'bold 9px monospace';
          const txt = `${edge.type}${edge.versionConstraint ? ` [${edge.versionConstraint}]` : ''}`;
          const m = ctx.measureText(txt);
          const pad = 4;

          ctx.fillStyle = 'rgba(10, 13, 20, 0.9)';
          ctx.fillRect(labelX - m.width / 2 - pad, labelY - 7 - pad, m.width + pad * 2, 14 + pad);
          ctx.strokeStyle = color;
          ctx.lineWidth = 1;
          ctx.strokeRect(labelX - m.width / 2 - pad, labelY - 7 - pad, m.width + pad * 2, 14 + pad);

          ctx.fillStyle = color;
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText(txt, labelX, labelY);
        }
      });

      ctx.globalAlpha = 1.0;

      // -----------------------------------------------------------------------
      // DRAW NODES
      // -----------------------------------------------------------------------
      activeNodes.forEach((node) => {
        const pos = posMapRef.current.get(node.id);
        if (!pos) return;

        const isSelected = selectedNodeId === node.id;
        const isHovered = hoveredNodeRef.current?.id === node.id;
        const isMatch = searchQuery ? node.name.toLowerCase().includes(searchQuery.toLowerCase()) : true;
        const color = getNodeColor(node.type);

        const radius = node.type === 'ai_model' || node.type === 'package' ? 24 : 18;

        // Dim if search doesn't match
        ctx.globalAlpha = isMatch ? 1.0 : 0.25;

        // Outer glow on selected/hovered
        if (isSelected || isHovered) {
          ctx.save();
          ctx.shadowColor = color;
          ctx.shadowBlur = 18;
          ctx.strokeStyle = color;
          ctx.lineWidth = 3;
          ctx.beginPath();
          ctx.arc(pos.x, pos.y, radius + 5, 0, Math.PI * 2);
          ctx.stroke();
          ctx.restore();
        }

        // Base node circle/shape
        ctx.fillStyle = '#0f172a';
        ctx.strokeStyle = isSelected ? '#ffffff' : color;
        ctx.lineWidth = isSelected ? 2.6 : 1.8;

        if (node.type === 'package') {
          // Rounded square / container shape for package
          const s = radius * 1.7;
          ctx.beginPath();
          ctx.roundRect(pos.x - s / 2, pos.y - s / 2, s, s, 6);
          ctx.fill();
          ctx.stroke();
        } else if (node.type === 'ai_model') {
          // Neural orb circle
          ctx.beginPath();
          ctx.arc(pos.x, pos.y, radius, 0, Math.PI * 2);
          ctx.fill();
          ctx.stroke();

          // Internal neural rings
          ctx.strokeStyle = `${color}44`;
          ctx.beginPath();
          ctx.arc(pos.x, pos.y, radius * 0.6, 0, Math.PI * 2);
          ctx.stroke();
        } else if (node.type === 'computation') {
          // Diamond shape
          ctx.beginPath();
          ctx.moveTo(pos.x, pos.y - radius);
          ctx.lineTo(pos.x + radius, pos.y);
          ctx.lineTo(pos.x, pos.y + radius);
          ctx.lineTo(pos.x - radius, pos.y);
          ctx.closePath();
          ctx.fill();
          ctx.stroke();
        } else {
          // Standard node circle
          ctx.beginPath();
          ctx.arc(pos.x, pos.y, radius, 0, Math.PI * 2);
          ctx.fill();
          ctx.stroke();
        }

        // Inner Type Icon Initial
        ctx.font = 'bold 11px monospace';
        ctx.fillStyle = color;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        const glyph =
          node.type === 'package' ? 'PKG' :
          node.type === 'ai_model' ? 'AI' :
          node.type === 'code_module' ? 'MOD' :
          node.type === 'computation' ? 'CMP' :
          node.type === 'dataset' ? 'DAT' : 'ENT';
        ctx.fillText(glyph, pos.x, pos.y);

        // Verification Badge indicator
        if (node.evidence && node.evidence.length > 0) {
          ctx.fillStyle = '#10b981'; // Green certified check dot
          ctx.beginPath();
          ctx.arc(pos.x + radius * 0.7, pos.y - radius * 0.7, 4.5, 0, Math.PI * 2);
          ctx.fill();
          ctx.strokeStyle = '#0f172a';
          ctx.lineWidth = 1.5;
          ctx.stroke();
        }

        // Conflict Warning indicator if involved in conflicts_with
        const hasConflict = edges.some((e) => (e.sourceId === node.id || e.targetId === node.id) && e.type === 'conflicts_with');
        if (hasConflict) {
          ctx.fillStyle = '#f43f5e';
          ctx.beginPath();
          ctx.arc(pos.x - radius * 0.7, pos.y - radius * 0.7, 4.5, 0, Math.PI * 2);
          ctx.fill();
          ctx.strokeStyle = '#0f172a';
          ctx.lineWidth = 1.5;
          ctx.stroke();
        }

        // Label under node
        ctx.font = isSelected ? 'bold 12px -apple-system, sans-serif' : '11px -apple-system, sans-serif';
        ctx.fillStyle = isSelected ? '#ffffff' : '#e2e8f0';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'top';
        ctx.fillText(node.name, pos.x, pos.y + radius + 5);

        // Version / Subtype pill
        if (node.version) {
          ctx.font = '9px monospace';
          ctx.fillStyle = 'rgba(148, 163, 184, 0.75)';
          ctx.fillText(`v${node.version}`, pos.x, pos.y + radius + 19);
        }
      });

      ctx.restore();
      ctx.restore();

      animationFrameIdRef.current = requestAnimationFrame(render);
    };

    animationFrameIdRef.current = requestAnimationFrame(render);
    return () => {
      isRunning = false;
      cancelAnimationFrame(animationFrameIdRef.current);
    };
  }, [nodes, edges, selectedNodeId, selectedEdgeId, filteredNodeTypes, filteredEdgeTypes, searchQuery]);

  // Pointer event interactions (drag, pan, click, hover)
  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;

    // Convert to world space
    const width = canvas.clientWidth;
    const height = canvas.clientHeight;
    const worldX = (mouseX - (width / 2 + transformRef.current.x)) / transformRef.current.k;
    const worldY = (mouseY - (height / 2 + transformRef.current.y)) / transformRef.current.k;

    // Check hit on active nodes
    const hitNode = nodes.find((n) => {
      if (!filteredNodeTypes.has(n.type)) return false;
      const p = posMapRef.current.get(n.id);
      if (!p) return false;
      return Math.hypot(p.x - worldX, p.y - worldY) < 28;
    });

    if (hitNode) {
      draggedNodeRef.current = hitNode;
      onSelectNode(hitNode);
    } else {
      isDraggingRef.current = true;
      dragStartRef.current = { x: e.clientX, y: e.clientY };
    }
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;

    const width = canvas.clientWidth;
    const height = canvas.clientHeight;
    const worldX = (mouseX - (width / 2 + transformRef.current.x)) / transformRef.current.k;
    const worldY = (mouseY - (height / 2 + transformRef.current.y)) / transformRef.current.k;

    if (draggedNodeRef.current) {
      const p = posMapRef.current.get(draggedNodeRef.current.id);
      if (p) {
        p.x = worldX;
        p.y = worldY;
        p.vx = 0;
        p.vy = 0;
      }
      return;
    }

    if (isDraggingRef.current) {
      const dx = e.clientX - dragStartRef.current.x;
      const dy = e.clientY - dragStartRef.current.y;
      transformRef.current.x += dx;
      transformRef.current.y += dy;
      dragStartRef.current = { x: e.clientX, y: e.clientY };
      return;
    }

    // Hover inspection
    const hit = nodes.find((n) => {
      if (!filteredNodeTypes.has(n.type)) return false;
      const p = posMapRef.current.get(n.id);
      if (!p) return false;
      return Math.hypot(p.x - worldX, p.y - worldY) < 28;
    });

    hoveredNodeRef.current = hit || null;
  };

  const handlePointerUp = () => {
    isDraggingRef.current = false;
    draggedNodeRef.current = null;
  };

  const handleWheel = (e: React.WheelEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    const zoomFactor = e.deltaY < 0 ? 1.1 : 0.9;
    transformRef.current.k = Math.max(0.35, Math.min(3.2, transformRef.current.k * zoomFactor));
  };

  return (
    <div className="relative w-full h-full overflow-hidden select-none">
      <canvas
        ref={canvasRef}
        className="w-full h-full block cursor-grab active:cursor-grabbing"
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerLeave={handlePointerUp}
        onWheel={handleWheel}
      />
    </div>
  );
};
