import React, { useState, useEffect } from 'react';
import { ExperimentRun, EvidenceReceipt, EcosystemNode, ObservableEdge } from '../types/ecosystem';
import {
  FlaskConical,
  Play,
  CheckCircle2,
  AlertTriangle,
  Terminal,
  ShieldCheck,
  X,
  RefreshCw,
  Hash,
  ExternalLink,
  ChevronRight,
  FileCheck,
  Check,
} from 'lucide-react';

interface ExperimentModalProps {
  isOpen: boolean;
  onClose: () => void;
  experiments: ExperimentRun[];
  nodes: EcosystemNode[];
  edges: ObservableEdge[];
  onCompleteExperiment: (
    experiment: ExperimentRun,
    receipt: EvidenceReceipt,
    resolvedEdgeId?: string,
    newEdge?: ObservableEdge
  ) => void;
  targetExperimentId?: string | null;
}

export const ExperimentModal: React.FC<ExperimentModalProps> = ({
  isOpen,
  onClose,
  experiments,
  nodes,
  edges,
  onCompleteExperiment,
  targetExperimentId,
}) => {
  const [selectedExpId, setSelectedExpId] = useState<string>(
    targetExperimentId || experiments[2]?.id || experiments[0]?.id || ''
  );
  const [isRunning, setIsRunning] = useState(false);
  const [currentStepIndex, setCurrentStepIndex] = useState(-1);
  const [terminalLogs, setTerminalLogs] = useState<string[]>([]);
  const [activeReceipt, setActiveReceipt] = useState<EvidenceReceipt | null>(null);

  useEffect(() => {
    if (targetExperimentId) {
      setSelectedExpId(targetExperimentId);
    }
  }, [targetExperimentId]);

  if (!isOpen) return null;

  const currentExperiment = experiments.find((e) => e.id === selectedExpId) || experiments[0];

  const handleRunExperiment = () => {
    if (!currentExperiment || isRunning) return;

    setIsRunning(true);
    setCurrentStepIndex(0);
    setActiveReceipt(null);
    setTerminalLogs([
      `[${new Date().toISOString()}] Initiating experiment: ${currentExperiment.id}`,
      `[CONFIG] Hypothesis: "${currentExperiment.hypothesis}"`,
      `[AUTH] Author: ${currentExperiment.author}`,
      `[SETUP] Isolating target sandbox for nodes: ${currentExperiment.targetNodeIds.join(', ')}`,
      `------------------------------------------------------------------------`,
    ]);

    // Simulated multi-step execution pipeline
    let step = 0;
    const interval = setInterval(() => {
      if (step < currentExperiment.steps.length) {
        const currentStep = currentExperiment.steps[step];
        setCurrentStepIndex(step);

        setTerminalLogs((prev) => [
          ...prev,
          `[EXEC STEP ${step + 1}/${currentExperiment.steps.length}] ${currentStep.name}...`,
          `  -> ${currentStep.description}`,
          `  -> SUCCESS: ${currentStep.outputLog || 'Assertion verified under bare-metal harness.'}`,
        ]);

        step++;
      } else {
        clearInterval(interval);
        setIsRunning(false);

        // Generate cryptographic evidence receipt
        const generatedHash = Array.from({ length: 64 }, () =>
          Math.floor(Math.random() * 16).toString(16)
        ).join('');

        const receipt: EvidenceReceipt = {
          receiptId: `rcpt-${Date.now().toString().slice(-6)}`,
          experimentId: currentExperiment.id,
          timestamp: new Date().toISOString(),
          sha256Proof: generatedHash,
          verifierEntity: 'ent-trust-safety',
          signature: `SIG_ED25519_EXP_${Date.now().toString().slice(-4)}`,
          empiricalMetric:
            currentExperiment.id === 'exp-resolve-conflict-enclave'
              ? 'Zero side-channel leakage, SEV-SNP attestation verified'
              : 'Empirical benchmark verified within tolerances',
          verifiedResult:
            currentExperiment.id === 'exp-resolve-conflict-enclave'
              ? 'Resolved conflicts_with between auth-enclave and telemetry-stream'
              : 'Formal specification verified',
        };

        setActiveReceipt(receipt);
        setTerminalLogs((prev) => [
          ...prev,
          `------------------------------------------------------------------------`,
          `[MINT] Evidence Receipt Generated: ${receipt.receiptId}`,
          `[HASH] SHA-256 Proof: ${receipt.sha256Proof}`,
          `[SIGN] Enclave Signature: ${receipt.signature}`,
          `[STATUS] "The loop closes through new experiments, not by allowing a visualization to silently rewrite its own source of truth."`,
          `[MAP] Living System Map updated with verifiable evidence!`,
        ]);

        // If resolving the conflict experiment
        if (currentExperiment.id === 'exp-resolve-conflict-enclave') {
          const resolvedEdgeId = 'edge-cnf-1';
          const newVerifiedEdge: ObservableEdge = {
            id: 'edge-res-enclave-telemetry',
            sourceId: 'mod-auth-enclave',
            targetId: 'pkg-telemetry-stream',
            type: 'verifies',
            label: 'verifies [Attested eBPF Shim]',
            description: 'SEV-SNP hardware attestation verified zero memory leakage across secure enclave boundaries.',
            status: 'verified',
            evidenceId: receipt.receiptId,
            evidenceHash: receipt.sha256Proof,
            telemetry: {
              latencyMs: 1.2,
              throughputRps: 84000,
              errorRatePercent: 0,
              lastObservedIso: new Date().toISOString(),
            },
          };
          onCompleteExperiment(currentExperiment, receipt, resolvedEdgeId, newVerifiedEdge);
        } else {
          onCompleteExperiment(currentExperiment, receipt);
        }
      }
    }, 700);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
      <div
        className="w-full max-w-4xl bg-[#0c1017] border border-slate-700/80 rounded-xl shadow-2xl flex flex-col max-h-[90vh] overflow-hidden text-slate-200"
        role="dialog"
        aria-modal="true"
        aria-labelledby="modal-title"
      >
        {/* Modal Header */}
        <div className="p-5 border-b border-slate-800 bg-gradient-to-r from-slate-900 via-slate-900/90 to-slate-950 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-emerald-950/80 border border-emerald-700/60 text-emerald-400">
              <FlaskConical className="w-5 h-5" />
            </div>
            <div>
              <h2 id="modal-title" className="text-lg font-bold font-mono text-white flex items-center gap-2">
                Experiment Verification Studio
              </h2>
              <p className="text-xs text-slate-400">
                Closing the loop through empirical proofs &amp; immutable evidence minting
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Philosophical Motto Banner */}
          <div className="bg-sky-950/30 border border-sky-800/40 rounded-lg p-3.5 flex items-start gap-3 text-xs text-sky-200">
            <ShieldCheck className="w-4 h-4 text-sky-400 shrink-0 mt-0.5" />
            <div>
              <span className="font-semibold text-white">System Map Integrity Principle:</span>
              <p className="mt-0.5 leading-relaxed">
                "The loop closes through new experiments, not by allowing a visualization to silently rewrite its own source of truth."
                Every observable relationship is backed by test runs, fuzzing logs, or hardware attestation.
              </p>
            </div>
          </div>

          {/* Select Experiment List */}
          <div>
            <label className="block text-xs font-mono uppercase tracking-wider text-slate-400 mb-2">
              Select Verifiable Experiment
            </label>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {experiments.map((exp) => {
                const isSelected = exp.id === selectedExpId;
                const isConflictResolver = exp.id === 'exp-resolve-conflict-enclave';
                return (
                  <button
                    key={exp.id}
                    onClick={() => {
                      setSelectedExpId(exp.id);
                      setTerminalLogs([]);
                      setActiveReceipt(null);
                      setCurrentStepIndex(-1);
                    }}
                    className={`p-3.5 rounded-lg border text-left transition-all relative ${
                      isSelected
                        ? 'bg-slate-800/90 border-sky-500 shadow-md ring-1 ring-sky-500/30'
                        : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    {isConflictResolver && (
                      <span className="absolute -top-2 -right-2 px-1.5 py-0.5 rounded text-[10px] font-mono font-bold bg-rose-950 text-rose-300 border border-rose-700 shadow">
                        CONFLICT FIX
                      </span>
                    )}
                    <div className="font-mono text-xs font-bold text-white truncate">{exp.title}</div>
                    <div className="text-[11px] text-slate-400 mt-1 line-clamp-2 leading-snug">
                      {exp.hypothesis}
                    </div>
                    <div className="mt-2 pt-2 border-t border-slate-800 flex items-center justify-between text-[10px] font-mono text-slate-500">
                      <span>{exp.author.split('(')[0].trim()}</span>
                      <span className={`${exp.status === 'completed' ? 'text-emerald-400 font-bold' : 'text-amber-400'}`}>
                        {exp.status.toUpperCase()}
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Current Experiment Details */}
          {currentExperiment && (
            <div className="bg-slate-900/70 rounded-xl border border-slate-800 p-5 space-y-4">
              <div className="flex items-start justify-between gap-4 flex-wrap">
                <div>
                  <span className="text-xs font-mono text-sky-400 font-semibold">{currentExperiment.id}</span>
                  <h3 className="text-base font-bold font-mono text-white mt-0.5">{currentExperiment.title}</h3>
                  <p className="text-xs text-slate-300 mt-1 italic">"{currentExperiment.hypothesis}"</p>
                </div>
                <button
                  onClick={handleRunExperiment}
                  disabled={isRunning}
                  className={`px-4 py-2 rounded-lg font-mono text-xs font-bold flex items-center gap-2 transition-all shadow-lg ${
                    isRunning
                      ? 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
                      : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-900/50 hover:shadow-emerald-700/60'
                  }`}
                >
                  {isRunning ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin text-emerald-400" />
                      <span>Executing Pipeline...</span>
                    </>
                  ) : (
                    <>
                      <Play className="w-4 h-4 fill-white" />
                      <span>Execute Experiment</span>
                    </>
                  )}
                </button>
              </div>

              {/* Steps Progress */}
              <div className="space-y-2 pt-3 border-t border-slate-800">
                <span className="text-xs font-mono uppercase tracking-wider text-slate-400 block mb-2">
                  Verification Execution Steps
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2">
                  {currentExperiment.steps.map((st, i) => {
                    const isDone = currentStepIndex > i || currentExperiment.status === 'completed';
                    const isCurrent = currentStepIndex === i && isRunning;
                    return (
                      <div
                        key={i}
                        className={`p-2.5 rounded-lg border text-xs font-mono transition-all ${
                          isDone
                            ? 'bg-emerald-950/40 border-emerald-800 text-emerald-300'
                            : isCurrent
                            ? 'bg-sky-950/60 border-sky-600 text-sky-200 animate-pulse'
                            : 'bg-slate-950/60 border-slate-800 text-slate-500'
                        }`}
                      >
                        <div className="flex items-center gap-1.5 font-bold mb-1">
                          {isDone ? (
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                          ) : (
                            <span className="w-3.5 h-3.5 rounded-full border border-slate-700 flex items-center justify-center text-[9px]">
                              {i + 1}
                            </span>
                          )}
                          <span className="truncate">{st.name}</span>
                        </div>
                        <p className="text-[10px] text-slate-400 line-clamp-2 leading-tight">{st.description}</p>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Live Terminal Output */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-xs font-mono uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                    <Terminal className="w-3.5 h-3.5 text-emerald-400" />
                    Live Execution Telemetry &amp; Log Output
                  </span>
                  <span className="text-[10px] font-mono text-slate-500">
                    {terminalLogs.length} events logged
                  </span>
                </div>
                <div className="bg-[#070a0f] border border-slate-800 rounded-lg p-3 font-mono text-xs text-emerald-400/90 h-44 overflow-y-auto space-y-1 shadow-inner">
                  {terminalLogs.length === 0 ? (
                    <div className="text-slate-600 italic py-6 text-center">
                      Ready to execute. Click "Execute Experiment" to run the bare-metal harness and mint empirical evidence.
                    </div>
                  ) : (
                    terminalLogs.map((log, idx) => (
                      <div key={idx} className="leading-snug">
                        {log}
                      </div>
                    ))
                  )}
                </div>
              </div>

              {/* Minted Evidence Receipt Card */}
              {(activeReceipt || currentExperiment.resultingEvidence) && (
                <div className="bg-emerald-950/30 border border-emerald-700/60 rounded-lg p-4 space-y-2.5">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-mono font-bold text-emerald-400 flex items-center gap-1.5">
                      <FileCheck className="w-4 h-4 text-emerald-400" />
                      Cryptographic Evidence Receipt Backing Edge Truth
                    </span>
                    <span className="text-xs font-mono text-emerald-300 font-bold">
                      {(activeReceipt || currentExperiment.resultingEvidence)?.receiptId}
                    </span>
                  </div>

                  <div className="text-xs font-mono grid grid-cols-1 md:grid-cols-2 gap-2 text-slate-300">
                    <div>
                      <span className="text-slate-500 block text-[10px]">VERIFIED METRIC</span>
                      <span className="text-white">
                        {(activeReceipt || currentExperiment.resultingEvidence)?.empiricalMetric}
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-500 block text-[10px]">VERIFIER ENTITY</span>
                      <span className="text-sky-300">
                        {(activeReceipt || currentExperiment.resultingEvidence)?.verifierEntity}
                      </span>
                    </div>
                  </div>

                  <div className="bg-black/60 p-2 rounded border border-slate-800 text-[11px] font-mono flex items-center justify-between gap-2">
                    <span className="text-slate-400 truncate">
                      SHA-256 Proof: {(activeReceipt || currentExperiment.resultingEvidence)?.sha256Proof}
                    </span>
                    <span className="text-emerald-400 text-[10px] uppercase font-bold shrink-0">
                      ✓ Merkle Leaf Signed
                    </span>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-900/80 flex items-center justify-between text-xs font-mono">
          <span className="text-slate-400">
            Target Nodes: <span className="text-sky-400">{currentExperiment.targetNodeIds.join(', ')}</span>
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors"
          >
            Close Studio
          </button>
        </div>
      </div>
    </div>
  );
};
