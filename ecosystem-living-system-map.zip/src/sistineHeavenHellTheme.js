import * as THREE from 'three';

// =============================================================================
// Sistine Chapel Frescoes & Metaphysical Board Generator (Heaven vs Hell)
// Michelangelo's Creation of Adam, The Last Judgment, and Divine/Infernal Art
// =============================================================================

/**
 * Procedural Sistine Chapel Nave Barrel Vault Fresco (2048 x 1024)
 * Centerpiece: Michelangelo's "The Creation of Adam"
 * Flanking: "Separation of Light from Darkness", "Creation of Sun & Moon"
 * Transverse marble ribs, gilded cornices, prophets & ignudi medallions
 */
export function createSistineCeilingTexture(maxAnisotropy = 8) {
  const canvas = document.createElement('canvas');
  canvas.width = 2048;
  canvas.height = 1024;
  const ctx = canvas.getContext('2d');
  if (!ctx) return new THREE.CanvasTexture(canvas);

  // 1. Warm Antique Italian Fresco Plaster Base
  const baseGrad = ctx.createLinearGradient(0, 0, 0, 1024);
  baseGrad.addColorStop(0.0, '#3a2d22');
  baseGrad.addColorStop(0.15, '#c9b79c');
  baseGrad.addColorStop(0.5, '#e4d6c0');
  baseGrad.addColorStop(0.85, '#c9b79c');
  baseGrad.addColorStop(1.0, '#3a2d22');
  ctx.fillStyle = baseGrad;
  ctx.fillRect(0, 0, 2048, 1024);

  // Subtle plaster texture & craquelure grain
  ctx.fillStyle = 'rgba(0, 0, 0, 0.03)';
  for (let i = 0; i < 40000; i++) {
    const rx = Math.random() * 2048;
    const ry = Math.random() * 1024;
    ctx.fillRect(rx, ry, Math.random() * 2 + 1, Math.random() * 2 + 1);
  }

  // 2. Classical Trompe-l'œil Architectural Cornices & Vault Ribs
  const numBays = 5;
  const bayW = 2048 / numBays;

  for (let i = 0; i <= numBays; i++) {
    const x = i * bayW;
    // Transverse fluted marble rib
    const ribGrad = ctx.createLinearGradient(x - 28, 0, x + 28, 0);
    ribGrad.addColorStop(0.0, '#4a3d2e');
    ribGrad.addColorStop(0.3, '#d8cbb8');
    ribGrad.addColorStop(0.5, '#f5ede0');
    ribGrad.addColorStop(0.7, '#d8cbb8');
    ribGrad.addColorStop(1.0, '#4a3d2e');
    ctx.fillStyle = ribGrad;
    ctx.fillRect(x - 26, 0, 52, 1024);

    // Gilded egg-and-dart gold bead trim
    ctx.fillStyle = '#d4af37';
    ctx.fillRect(x - 4, 0, 8, 1024);
    ctx.fillStyle = '#fff0a6';
    for (let y = 16; y < 1024; y += 32) {
      ctx.beginPath();
      ctx.arc(x, y, 3.5, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  // Upper & Lower Horizontal Cornice Bands with Gilded Modillions
  const hCorniceH = 140;
  for (const y of [0, 1024 - hCorniceH]) {
    const hGrad = ctx.createLinearGradient(0, y, 0, y + hCorniceH);
    hGrad.addColorStop(0.0, y === 0 ? '#2a2016' : '#9e8972');
    hGrad.addColorStop(0.5, '#c7b49b');
    hGrad.addColorStop(1.0, y === 0 ? '#9e8972' : '#2a2016');
    ctx.fillStyle = hGrad;
    ctx.fillRect(0, y, 2048, hCorniceH);

    // Gilded filigree border
    ctx.fillStyle = '#b89428';
    ctx.fillRect(0, y === 0 ? hCorniceH - 12 : y, 2048, 12);
  }

  // =========================================================================
  // BAY 3 (CENTER): Michelangelo's "The Creation of Adam" (Creazione di Adamo)
  // =========================================================================
  const bayCenterIdx = 2;
  const bX0 = bayCenterIdx * bayW + 28;
  const bW = bayW - 56;
  const bY0 = 155;
  const bH = 1024 - 310;

  // Lapis Lazuli Ethereal Sky Background
  const skyGrad = ctx.createRadialGradient(bX0 + bW * 0.5, bY0 + bH * 0.5, 40, bX0 + bW * 0.5, bY0 + bH * 0.5, bW * 0.55);
  skyGrad.addColorStop(0.0, '#fefbf0');
  skyGrad.addColorStop(0.25, '#cce0f5');
  skyGrad.addColorStop(0.65, '#5c84b8');
  skyGrad.addColorStop(1.0, '#2e4975');
  ctx.fillStyle = skyGrad;
  ctx.fillRect(bX0, bY0, bW, bH);

  // Golden Divine Mandorla (God the Father enveloped in the swirling celestial mantle)
  const godCenterX = bX0 + bW * 0.72;
  const godCenterY = bY0 + bH * 0.44;

  ctx.save();
  // Celestial red/terracotta billowing cloak (often likened to the human brain/heart)
  ctx.beginPath();
  ctx.ellipse(godCenterX, godCenterY, bW * 0.22, bH * 0.38, -0.22, 0, Math.PI * 2);
  const cloakGrad = ctx.createRadialGradient(godCenterX - 20, godCenterY - 30, 20, godCenterX, godCenterY, bW * 0.24);
  cloakGrad.addColorStop(0.0, '#c74438');
  cloakGrad.addColorStop(0.4, '#99261f');
  cloakGrad.addColorStop(0.85, '#5c120e');
  cloakGrad.addColorStop(1.0, '#360906');
  ctx.fillStyle = cloakGrad;
  ctx.shadowColor = 'rgba(212, 175, 55, 0.65)';
  ctx.shadowBlur = 32;
  ctx.fill();
  ctx.restore();

  // Divine Golden Light Radiance inside the mantle
  const haloGrad = ctx.createRadialGradient(godCenterX, godCenterY, 10, godCenterX, godCenterY, bW * 0.16);
  haloGrad.addColorStop(0.0, 'rgba(255, 245, 196, 0.85)');
  haloGrad.addColorStop(0.5, 'rgba(245, 205, 80, 0.45)');
  haloGrad.addColorStop(1.0, 'rgba(255, 220, 100, 0.0)');
  ctx.fillStyle = haloGrad;
  ctx.beginPath();
  ctx.ellipse(godCenterX, godCenterY, bW * 0.18, bH * 0.30, -0.22, 0, Math.PI * 2);
  ctx.fill();

  // Cherubim & Seraphim heads around God
  const cherubCoords = [
    { dx: -45, dy: -60, r: 18 }, { dx: 35, dy: -70, r: 16 }, { dx: 65, dy: -20, r: 19 },
    { dx: 55, dy: 50, r: 18 }, { dx: -35, dy: 60, r: 16 }, { dx: 0, dy: 75, r: 17 }
  ];
  for (const ch of cherubCoords) {
    ctx.fillStyle = '#f2dec9';
    ctx.beginPath();
    ctx.arc(godCenterX + ch.dx, godCenterY + ch.dy, ch.r, 0, Math.PI * 2);
    ctx.fill();
    // Golden halo around cherub
    ctx.strokeStyle = 'rgba(245, 215, 110, 0.65)';
    ctx.lineWidth = 1.5;
    ctx.stroke();
  }

  // God the Creator (The Almighty) — Flowing White Beard, Rose Tunic, Outstretched Right Arm
  // Torso & Tunic
  ctx.fillStyle = '#e8d5cc';
  ctx.beginPath();
  ctx.ellipse(godCenterX - 10, godCenterY + 10, 36, 52, -0.3, 0, Math.PI * 2);
  ctx.fill();

  // Face & Flowing Silver Beard
  ctx.fillStyle = '#e0c4b2';
  ctx.beginPath();
  ctx.arc(godCenterX - 15, godCenterY - 30, 22, 0, Math.PI * 2);
  ctx.fill();
  // Flowing majestic white beard
  ctx.fillStyle = '#f8f6f0';
  ctx.beginPath();
  ctx.moveTo(godCenterX - 32, godCenterY - 24);
  ctx.quadraticCurveTo(godCenterX - 45, godCenterY + 12, godCenterX - 22, godCenterY + 32);
  ctx.quadraticCurveTo(godCenterX - 10, godCenterY + 12, godCenterX + 4, godCenterY - 20);
  ctx.closePath();
  ctx.fill();

  // God's Divine Outstretched Right Arm reaching left toward Adam
  ctx.strokeStyle = '#e2c6b4';
  ctx.lineWidth = 18;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(godCenterX - 25, godCenterY - 10);
  ctx.quadraticCurveTo(godCenterX - 75, godCenterY - 14, bX0 + bW * 0.525, bY0 + bH * 0.49);
  ctx.stroke();

  // Divine Forefinger extending toward Adam
  ctx.strokeStyle = '#eed2c0';
  ctx.lineWidth = 6;
  ctx.beginPath();
  ctx.moveTo(bX0 + bW * 0.525, bY0 + bH * 0.49);
  ctx.lineTo(bX0 + bW * 0.505, bY0 + bH * 0.498);
  ctx.stroke();

  // =========================================================================
  // ADAM: Reclining on the Verdant Earth, reaching upward to God
  // =========================================================================
  const adamBaseX = bX0 + bW * 0.16;
  const adamBaseY = bY0 + bH * 0.66;

  // Green Earth / Hill of Eden
  ctx.fillStyle = '#3f5934';
  ctx.beginPath();
  ctx.moveTo(bX0, bY0 + bH);
  ctx.lineTo(bX0, bY0 + bH * 0.60);
  ctx.quadraticCurveTo(bX0 + bW * 0.22, bY0 + bH * 0.52, bX0 + bW * 0.45, bY0 + bH);
  ctx.closePath();
  ctx.fill();
  ctx.fillStyle = '#617d4a';
  ctx.beginPath();
  ctx.moveTo(bX0, bY0 + bH * 0.63);
  ctx.quadraticCurveTo(bX0 + bW * 0.20, bY0 + bH * 0.54, bX0 + bW * 0.38, bY0 + bH * 0.88);
  ctx.lineTo(bX0, bY0 + bH * 0.88);
  ctx.closePath();
  ctx.fill();

  // Adam's Sculpted Reclining Torso
  ctx.fillStyle = '#d9bda9';
  ctx.beginPath();
  ctx.ellipse(adamBaseX + 45, adamBaseY - 20, 34, 48, 0.4, 0, Math.PI * 2);
  ctx.fill();

  // Adam's Profile & Head
  ctx.fillStyle = '#d4b39b';
  ctx.beginPath();
  ctx.arc(adamBaseX + 60, adamBaseY - 60, 20, 0, Math.PI * 2);
  ctx.fill();
  // Classical brown Renaissance curls
  ctx.fillStyle = '#5c3d26';
  ctx.beginPath();
  ctx.arc(adamBaseX + 64, adamBaseY - 64, 18, Math.PI * 0.7, Math.PI * 1.9);
  ctx.fill();

  // Adam's Left Arm extending up & right toward God's finger
  ctx.strokeStyle = '#d9bda9';
  ctx.lineWidth = 14;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(adamBaseX + 50, adamBaseY - 35);
  ctx.quadraticCurveTo(adamBaseX + 90, adamBaseY - 45, bX0 + bW * 0.47, bY0 + bH * 0.505);
  ctx.stroke();

  // Adam's Index Finger extending toward God's finger
  ctx.strokeStyle = '#dfc3b0';
  ctx.lineWidth = 5;
  ctx.beginPath();
  ctx.moveTo(bX0 + bW * 0.47, bY0 + bH * 0.505);
  ctx.lineTo(bX0 + bW * 0.490, bY0 + bH * 0.501);
  ctx.stroke();

  // =========================================================================
  // THE DIVINE SPARK: Golden Celestial Energy Flash between the two fingers!
  // =========================================================================
  const sparkX = bX0 + bW * 0.4975;
  const sparkY = bY0 + bH * 0.500;
  const sparkGrad = ctx.createRadialGradient(sparkX, sparkY, 1, sparkX, sparkY, 26);
  sparkGrad.addColorStop(0.0, '#ffffff');
  sparkGrad.addColorStop(0.2, '#fff6bd');
  sparkGrad.addColorStop(0.5, '#f5d76e');
  sparkGrad.addColorStop(0.85, 'rgba(212, 175, 55, 0.45)');
  sparkGrad.addColorStop(1.0, 'rgba(212, 175, 55, 0.0)');
  ctx.fillStyle = sparkGrad;
  ctx.beginPath();
  ctx.arc(sparkX, sparkY, 26, 0, Math.PI * 2);
  ctx.fill();

  // Golden cross star flare
  ctx.strokeStyle = '#ffffff';
  ctx.lineWidth = 2.5;
  ctx.beginPath();
  ctx.moveTo(sparkX - 22, sparkY); ctx.lineTo(sparkX + 22, sparkY);
  ctx.moveTo(sparkX, sparkY - 22); ctx.lineTo(sparkX, sparkY + 22);
  ctx.stroke();

  // Latin Calligraphic Inscription on Cartouche
  ctx.fillStyle = 'rgba(20, 16, 12, 0.72)';
  ctx.fillRect(bX0 + bW * 0.28, bY0 + bH - 42, bW * 0.44, 32);
  ctx.strokeStyle = '#d4af37';
  ctx.lineWidth = 1.5;
  ctx.strokeRect(bX0 + bW * 0.28, bY0 + bH - 42, bW * 0.44, 32);
  ctx.font = 'bold 15px Georgia, serif';
  ctx.textAlign = 'center';
  ctx.fillStyle = '#f5d76e';
  ctx.fillText('CREATIO ADAE • MICHELANGELUS • 1512', bX0 + bW * 0.5, bY0 + bH - 21);

  // =========================================================================
  // BAY 2 (LEFT): Separation of Light from Darkness (Divisio Lucis ac Tenebrarum)
  // =========================================================================
  const b2X0 = 1 * bayW + 28;
  const b2W = bayW - 56;
  const b2Grad = ctx.createLinearGradient(b2X0, bY0, b2X0 + b2W, bY0 + bH);
  b2Grad.addColorStop(0.0, '#fff4cc');
  b2Grad.addColorStop(0.35, '#e0a842');
  b2Grad.addColorStop(0.55, '#3b2554');
  b2Grad.addColorStop(1.0, '#0c0814');
  ctx.fillStyle = b2Grad;
  ctx.fillRect(b2X0, bY0, b2W, bH);

  // Swirling God parting the cosmic realms
  ctx.fillStyle = 'rgba(255, 230, 140, 0.65)';
  ctx.beginPath();
  ctx.arc(b2X0 + b2W * 0.35, bY0 + bH * 0.45, b2W * 0.25, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = 'rgba(20, 16, 12, 0.72)';
  ctx.fillRect(b2X0 + b2W * 0.18, bY0 + bH - 42, b2W * 0.64, 32);
  ctx.strokeStyle = '#d4af37';
  ctx.lineWidth = 1.5;
  ctx.strokeRect(b2X0 + b2W * 0.18, bY0 + bH - 42, b2W * 0.64, 32);
  ctx.font = 'bold 13px Georgia, serif';
  ctx.fillStyle = '#f5d76e';
  ctx.fillText('DIVISIO LUCIS AC TENEBRARUM', b2X0 + b2W * 0.5, bY0 + bH - 21);

  // =========================================================================
  // BAY 4 (RIGHT): Creation of the Sun, Moon, and Planets
  // =========================================================================
  const b4X0 = 3 * bayW + 28;
  const b4W = bayW - 56;
  const b4Grad = ctx.createRadialGradient(b4X0 + b4W * 0.38, bY0 + bH * 0.42, 20, b4X0 + b4W * 0.5, bY0 + bH * 0.5, b4W * 0.6);
  b4Grad.addColorStop(0.0, '#fffae0');
  b4Grad.addColorStop(0.3, '#f59e0b');
  b4Grad.addColorStop(0.7, '#253554');
  b4Grad.addColorStop(1.0, '#0f172a');
  ctx.fillStyle = b4Grad;
  ctx.fillRect(b4X0, bY0, b4W, bH);

  // Radiant Golden Sun
  const sunGrad = ctx.createRadialGradient(b4X0 + b4W * 0.35, bY0 + bH * 0.40, 10, b4X0 + b4W * 0.35, bY0 + bH * 0.40, 58);
  sunGrad.addColorStop(0.0, '#ffffff');
  sunGrad.addColorStop(0.35, '#ffdd55');
  sunGrad.addColorStop(0.75, '#ea580c');
  sunGrad.addColorStop(1.0, 'transparent');
  ctx.fillStyle = sunGrad;
  ctx.beginPath();
  ctx.arc(b4X0 + b4W * 0.35, bY0 + bH * 0.40, 58, 0, Math.PI * 2);
  ctx.fill();

  // Silver Crescent Moon
  ctx.fillStyle = '#e2e8f0';
  ctx.beginPath();
  ctx.arc(b4X0 + b4W * 0.72, bY0 + bH * 0.46, 32, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#1e293b';
  ctx.beginPath();
  ctx.arc(b4X0 + b4W * 0.68, bY0 + bH * 0.44, 28, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = 'rgba(20, 16, 12, 0.72)';
  ctx.fillRect(b4X0 + b4W * 0.20, bY0 + bH - 42, b4W * 0.60, 32);
  ctx.strokeStyle = '#d4af37';
  ctx.lineWidth = 1.5;
  ctx.strokeRect(b4X0 + b4W * 0.20, bY0 + bH - 42, b4W * 0.60, 32);
  ctx.font = 'bold 13px Georgia, serif';
  ctx.fillStyle = '#f5d76e';
  ctx.fillText('CREATIO SOLIS ET LUNAE', b4X0 + b4W * 0.5, bY0 + bH - 21);

  // Gilded architectural cartouches on Outer Bays 1 & 5
  for (const bayIdx of [0, 4]) {
    const x0 = bayIdx * bayW + 28;
    const w = bayW - 56;
    ctx.fillStyle = '#221a14';
    ctx.fillRect(x0, bY0, w, bH);
    ctx.strokeStyle = '#9c7b2a';
    ctx.lineWidth = 2;
    ctx.strokeRect(x0 + 12, bY0 + 12, w - 24, bH - 24);

    // Gilded Ignudi Medallion in center
    ctx.fillStyle = '#c5a038';
    ctx.beginPath();
    ctx.arc(x0 + w * 0.5, bY0 + bH * 0.5, 75, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = '#fef08a';
    ctx.lineWidth = 4;
    ctx.stroke();

    ctx.font = 'bold 14px Georgia, serif';
    ctx.textAlign = 'center';
    ctx.fillStyle = '#16100c';
    ctx.fillText(bayIdx === 0 ? 'IGNUDI • DELPHICA' : 'PROPHETA • ISAIAS', x0 + w * 0.5, bY0 + bH * 0.5 + 5);
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = maxAnisotropy;
  tex.wrapS = THREE.ClampToEdgeWrapping;
  tex.wrapT = THREE.ClampToEdgeWrapping;
  tex.needsUpdate = true;
  return tex;
}

/**
 * Procedural "The Last Judgment" (Il Giudizio Universale) Altar Mural Texture (1024 x 1024)
 * Upper: Christ the Judge, Virgin Mary, Saints ascending to golden Heaven
 * Lower: The Damned plunging into the flaming Pit of Hell, Charon's barge on the river Styx
 */
export function createLastJudgmentTexture(maxAnisotropy = 8) {
  const canvas = document.createElement('canvas');
  canvas.width = 1024;
  canvas.height = 1024;
  const ctx = canvas.getContext('2d');
  if (!ctx) return new THREE.CanvasTexture(canvas);

  // Background Split: Golden celestial empyrean above, dark fiery infernal abyss below
  const bgGrad = ctx.createLinearGradient(0, 0, 0, 1024);
  bgGrad.addColorStop(0.0, '#386fa4');
  bgGrad.addColorStop(0.25, '#cce3f5');
  bgGrad.addColorStop(0.48, '#e8b868');
  bgGrad.addColorStop(0.58, '#822416');
  bgGrad.addColorStop(0.82, '#380a06');
  bgGrad.addColorStop(1.0, '#100302');
  ctx.fillStyle = bgGrad;
  ctx.fillRect(0, 0, 1024, 1024);

  // Upper Celestial Glow around Christ the Judge
  const christX = 512;
  const christY = 260;
  const christGlow = ctx.createRadialGradient(christX, christY, 15, christX, christY, 180);
  christGlow.addColorStop(0.0, '#ffffff');
  christGlow.addColorStop(0.3, '#fde047');
  christGlow.addColorStop(0.7, 'rgba(234, 179, 8, 0.45)');
  christGlow.addColorStop(1.0, 'transparent');
  ctx.fillStyle = christGlow;
  ctx.beginPath();
  ctx.arc(christX, christY, 180, 0, Math.PI * 2);
  ctx.fill();

  // Christ Figure (Right hand raised in divine judgment)
  ctx.fillStyle = '#fce7d8';
  ctx.beginPath();
  ctx.ellipse(christX, christY, 32, 60, 0, 0, Math.PI * 2);
  ctx.fill();
  // Raised right arm of judgment
  ctx.strokeStyle = '#fce7d8';
  ctx.lineWidth = 14;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(christX + 12, christY - 20);
  ctx.lineTo(christX + 45, christY - 65);
  ctx.stroke();

  // Virgin Mary beside Christ
  ctx.fillStyle = '#3b82f6';
  ctx.beginPath();
  ctx.ellipse(christX - 52, christY + 15, 24, 45, 0.25, 0, Math.PI * 2);
  ctx.fill();

  // Angels blowing the Trumpets of the Apocalypse (Center Register)
  for (const tx of [380, 440, 584, 644]) {
    ctx.fillStyle = '#fef08a';
    ctx.beginPath();
    ctx.arc(tx, 480, 16, 0, Math.PI * 2);
    ctx.fill();
    // Golden trumpet
    ctx.strokeStyle = '#d4af37';
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.moveTo(tx, 480);
    ctx.lineTo(tx + (tx < 512 ? -55 : 55), 525);
    ctx.stroke();
  }

  // LOWER REGISTER: The Damned plunging into the Infernal Gates of Hell
  // Boiling Lake of Fire & Brimstone (Lake of Sulfur)
  const lavaGrad = ctx.createLinearGradient(0, 680, 0, 1024);
  lavaGrad.addColorStop(0.0, '#b91c1c');
  lavaGrad.addColorStop(0.35, '#ea580c');
  lavaGrad.addColorStop(0.7, '#f59e0b');
  lavaGrad.addColorStop(1.0, '#7f1d1d');
  ctx.fillStyle = lavaGrad;
  ctx.fillRect(0, 720, 1024, 304);

  // Charon's Demonic Ferry with Oar
  ctx.fillStyle = '#1c1917';
  ctx.beginPath();
  ctx.ellipse(720, 840, 140, 36, -0.15, 0, Math.PI * 2);
  ctx.fill();
  // Charon horned silhouette
  ctx.fillStyle = '#0c0a09';
  ctx.beginPath();
  ctx.arc(680, 800, 24, 0, Math.PI * 2);
  ctx.fill();
  // Charon oar
  ctx.strokeStyle = '#44403c';
  ctx.lineWidth = 6;
  ctx.beginPath();
  ctx.moveTo(680, 790);
  ctx.lineTo(790, 890);
  ctx.stroke();

  // Horned Minos & demons dragging souls down on the right
  for (let i = 0; i < 12; i++) {
    const dx = 560 + Math.random() * 420;
    const dy = 660 + Math.random() * 280;
    ctx.fillStyle = 'rgba(20, 8, 8, 0.85)';
    ctx.beginPath();
    ctx.arc(dx, dy, 12, 0, Math.PI * 2);
    ctx.fill();
  }

  // Left side: The Righteous Ascending into Heaven
  for (let i = 0; i < 14; i++) {
    const ax = 60 + Math.random() * 320;
    const ay = 440 + Math.random() * 260;
    ctx.fillStyle = 'rgba(254, 240, 138, 0.75)';
    ctx.beginPath();
    ctx.arc(ax, ay, 10, 0, Math.PI * 2);
    ctx.fill();
  }

  // Classical Fresco Inscription Cartouche at Top
  ctx.fillStyle = 'rgba(15, 12, 8, 0.82)';
  ctx.fillRect(262, 28, 500, 44);
  ctx.strokeStyle = '#d4af37';
  ctx.lineWidth = 2;
  ctx.strokeRect(262, 28, 500, 44);
  ctx.font = 'bold 18px Georgia, serif';
  ctx.textAlign = 'center';
  ctx.fillStyle = '#f5d76e';
  ctx.fillText('IL GIUDIZIO UNIVERSALE • MICHELANGELO', 512, 56);

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = maxAnisotropy;
  tex.needsUpdate = true;
  return tex;
}

/**
 * Procedural Cosmatesque Inlaid Marble Sanctuary Floor (1024 x 1024)
 * Authentic 15th-century Vatican quincunx geometry:
 * Porphyry red discs, serpentine green guilloche borders, Carrara white & gold triangles
 */
export function createCosmatesqueFloorTexture(maxAnisotropy = 8) {
  const canvas = document.createElement('canvas');
  canvas.width = 1024;
  canvas.height = 1024;
  const ctx = canvas.getContext('2d');
  if (!ctx) return new THREE.CanvasTexture(canvas);

  // Base aged limestone floor
  ctx.fillStyle = '#b0a394';
  ctx.fillRect(0, 0, 1024, 1024);

  // Large Central Guilloche Circle (Quincunx center)
  const cx = 512;
  const cy = 512;

  // Outer Gilded Guilloche Interlace Band
  ctx.strokeStyle = '#c5a038';
  ctx.lineWidth = 22;
  ctx.beginPath();
  ctx.arc(cx, cy, 380, 0, Math.PI * 2);
  ctx.stroke();

  // Concentric Porphyry Red & Serpentine Green Rings
  const rings = [
    { r: 350, color: '#7a1f1d', w: 26 }, // Imperial Red Porphyry
    { r: 310, color: '#274e3b', w: 20 }, // Verde Antico Serpentine Green
    { r: 280, color: '#e5d9c5', w: 14 }, // White Carrara Marble
    { r: 250, color: '#9e7828', w: 18 }, // Gilded Siena Ochre
    { r: 210, color: '#7a1f1d', w: 32 }, // Central Porphyry Disc
    { r: 160, color: '#274e3b', w: 24 },
    { r: 120, color: '#c5a038', w: 16 },
    { r: 80,  color: '#7a1f1d', w: 40 }
  ];

  for (const ring of rings) {
    ctx.strokeStyle = ring.color;
    ctx.lineWidth = ring.w;
    ctx.beginPath();
    ctx.arc(cx, cy, ring.r, 0, Math.PI * 2);
    ctx.stroke();
  }

  // 4 Corner Satellite Porphyry Medallions
  const corners = [
    { x: 190, y: 190 }, { x: 834, y: 190 },
    { x: 190, y: 834 }, { x: 834, y: 834 }
  ];

  for (const c of corners) {
    ctx.fillStyle = '#7a1f1d';
    ctx.beginPath();
    ctx.arc(c.x, c.y, 110, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = '#c5a038';
    ctx.lineWidth = 12;
    ctx.stroke();
    ctx.strokeStyle = '#274e3b';
    ctx.lineWidth = 8;
    ctx.beginPath();
    ctx.arc(c.x, c.y, 75, 0, Math.PI * 2);
    ctx.stroke();
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = maxAnisotropy;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(2, 2);
  tex.needsUpdate = true;
  return tex;
}

// =============================================================================
// Chessboard Metaphysical Tiles: Heaven vs Hell
// =============================================================================

/**
 * Creates custom procedural tile textures for Heaven's side and Hell's side
 */
export function createMetaphysicalBoardTextures(maxAnisotropy = 8) {
  // 1. Heaven Light Square: Celestial White Carrara with Gilded Cosmatesque Cross
  const cHeavenLight = document.createElement('canvas');
  cHeavenLight.width = 256; cHeavenLight.height = 256;
  const ctxHL = cHeavenLight.getContext('2d');
  if (ctxHL) {
    const g = ctxHL.createRadialGradient(128, 128, 10, 128, 128, 140);
    g.addColorStop(0.0, '#faf7ee');
    g.addColorStop(0.7, '#ece5d4');
    g.addColorStop(1.0, '#dfd5be');
    ctxHL.fillStyle = g;
    ctxHL.fillRect(0, 0, 256, 256);
    // Gilded inlay border
    ctxHL.strokeStyle = 'rgba(212, 175, 55, 0.85)';
    ctxHL.lineWidth = 6;
    ctxHL.strokeRect(10, 10, 236, 236);
    ctxHL.strokeStyle = 'rgba(245, 215, 110, 0.5)';
    ctxHL.lineWidth = 2;
    ctxHL.strokeRect(18, 18, 220, 220);
    // Celestial radiant sunburst in center
    ctxHL.fillStyle = 'rgba(212, 175, 55, 0.35)';
    ctxHL.beginPath();
    ctxHL.arc(128, 128, 36, 0, Math.PI * 2);
    ctxHL.fill();
    ctxHL.strokeStyle = 'rgba(212, 175, 55, 0.75)';
    ctxHL.lineWidth = 3;
    ctxHL.beginPath();
    ctxHL.moveTo(128, 70); ctxHL.lineTo(128, 186);
    ctxHL.moveTo(70, 128); ctxHL.lineTo(186, 128);
    ctxHL.stroke();
  }

  // 2. Heaven Dark Square: Lapis Lazuli Deep Celestial Blue with Golden Renaissance Stars
  const cHeavenDark = document.createElement('canvas');
  cHeavenDark.width = 256; cHeavenDark.height = 256;
  const ctxHD = cHeavenDark.getContext('2d');
  if (ctxHD) {
    const g = ctxHD.createRadialGradient(128, 128, 20, 128, 128, 150);
    g.addColorStop(0.0, '#1e3860');
    g.addColorStop(0.65, '#132442');
    g.addColorStop(1.0, '#0a1426');
    ctxHD.fillStyle = g;
    ctxHD.fillRect(0, 0, 256, 256);
    // Gilded starburst border
    ctxHD.strokeStyle = 'rgba(212, 175, 55, 0.75)';
    ctxHD.lineWidth = 5;
    ctxHD.strokeRect(12, 12, 232, 232);
    // Golden Sistine 8-pointed star in center
    ctxHD.fillStyle = '#f5d76e';
    ctxHD.beginPath();
    const cx = 128, cy = 128;
    for (let i = 0; i < 8; i++) {
      const aOuter = (i * Math.PI) / 4;
      const aInner = aOuter + Math.PI / 8;
      const x1 = cx + Math.cos(aOuter) * 38;
      const y1 = cy + Math.sin(aOuter) * 38;
      const x2 = cx + Math.cos(aInner) * 14;
      const y2 = cy + Math.sin(aInner) * 14;
      if (i === 0) ctxHD.moveTo(x1, y1);
      else ctxHD.lineTo(x1, y1);
      ctxHD.lineTo(x2, y2);
    }
    ctxHD.closePath();
    ctxHD.fill();
  }

  // 3. Hell Light Square: Charred Volcanic Ashlar with Smoldering Crimson Veins
  const cHellLight = document.createElement('canvas');
  cHellLight.width = 256; cHellLight.height = 256;
  const ctxHLi = cHellLight.getContext('2d');
  if (ctxHLi) {
    const g = ctxHLi.createRadialGradient(128, 128, 20, 128, 128, 150);
    g.addColorStop(0.0, '#2b1e1b');
    g.addColorStop(0.7, '#1b1311');
    g.addColorStop(1.0, '#0f0a09');
    ctxHLi.fillStyle = g;
    ctxHLi.fillRect(0, 0, 256, 256);
    // Smoldering ember fissure
    ctxHLi.strokeStyle = 'rgba(234, 88, 12, 0.65)';
    ctxHLi.lineWidth = 4;
    ctxHLi.beginPath();
    ctxHLi.moveTo(40, 210);
    ctxHLi.quadraticCurveTo(120, 160, 135, 128);
    ctxHLi.quadraticCurveTo(150, 90, 220, 45);
    ctxHLi.stroke();
    ctxHLi.strokeStyle = 'rgba(255, 160, 40, 0.45)';
    ctxHLi.lineWidth = 2;
    ctxHLi.stroke();
    // Dark runic frame
    ctxHLi.strokeStyle = 'rgba(180, 50, 20, 0.55)';
    ctxHLi.lineWidth = 4;
    ctxHLi.strokeRect(10, 10, 236, 236);
  }

  // 4. Hell Dark Square: Cracked Obsidian Basalt with Glowing Magma Core
  const cHellDark = document.createElement('canvas');
  cHellDark.width = 256; cHellDark.height = 256;
  const ctxHDa = cHellDark.getContext('2d');
  if (ctxHDa) {
    ctxHDa.fillStyle = '#0a0707';
    ctxHDa.fillRect(0, 0, 256, 256);
    // Molten magma central vent
    const mg = ctxHDa.createRadialGradient(128, 128, 5, 128, 128, 70);
    mg.addColorStop(0.0, 'rgba(255, 230, 120, 0.85)');
    mg.addColorStop(0.25, 'rgba(255, 90, 15, 0.75)');
    mg.addColorStop(0.65, 'rgba(180, 20, 10, 0.45)');
    mg.addColorStop(1.0, 'transparent');
    ctxHDa.fillStyle = mg;
    ctxHDa.beginPath();
    ctxHDa.arc(128, 128, 70, 0, Math.PI * 2);
    ctxHDa.fill();
    // Obsidian jagged border
    ctxHDa.strokeStyle = 'rgba(160, 30, 20, 0.7)';
    ctxHDa.lineWidth = 5;
    ctxHDa.strokeRect(12, 12, 232, 232);
  }

  const makeTex = (canvas) => {
    const t = new THREE.CanvasTexture(canvas);
    t.colorSpace = THREE.SRGBColorSpace;
    t.anisotropy = maxAnisotropy;
    t.needsUpdate = true;
    return t;
  };

  return {
    heavenLightTex: makeTex(cHeavenLight),
    heavenDarkTex: makeTex(cHeavenDark),
    hellLightTex: makeTex(cHellLight),
    hellDarkTex: makeTex(cHellDark)
  };
}

// =============================================================================
// 3D Piece Adornments: Celestial Halos (God/Heaven) & Horns/Veins (The Devil/Hell)
// =============================================================================

/**
 * Attaches radiant celestial halos and golden solar crowns to God and the Heavenly Host
 */
export function attachHeavenlyAdornment(pieceRoot, type) {
  if (!pieceRoot) return;

  const haloGroup = new THREE.Group();
  haloGroup.name = 'heavenly_adornment';

  const goldHaloMat = new THREE.MeshStandardMaterial({
    color: 0xfff2a6,
    emissive: 0xd4af37,
    emissiveIntensity: 0.95,
    roughness: 0.15,
    metalness: 0.88
  });

  const holyGlowMat = new THREE.MeshBasicMaterial({
    color: 0xffe980,
    transparent: true,
    opacity: 0.45,
    blending: THREE.AdditiveBlending
  });

  if (type === 'king') {
    // GOD THE CREATOR: Majestic Radiant Halo with 12 Divine Solar Rays
    const ringGeo = new THREE.TorusGeometry(0.36, 0.038, 16, 48);
    ringGeo.rotateX(Math.PI / 2);
    const ringMesh = new THREE.Mesh(ringGeo, goldHaloMat);
    ringMesh.position.set(0, 1.82, 0);
    haloGroup.add(ringMesh);

    // Glowing aura disc
    const auraGeo = new THREE.RingGeometry(0.08, 0.38, 36);
    auraGeo.rotateX(Math.PI / 2);
    const auraMesh = new THREE.Mesh(auraGeo, holyGlowMat);
    auraMesh.position.set(0, 1.815, 0);
    haloGroup.add(auraMesh);

    // 12 Radiating Solar Beams
    const rayGeo = new THREE.ConeGeometry(0.024, 0.22, 8);
    for (let i = 0; i < 12; i++) {
      const angle = (i * Math.PI * 2) / 12;
      const ray = new THREE.Mesh(rayGeo, goldHaloMat);
      ray.position.set(Math.cos(angle) * 0.44, 1.82, Math.sin(angle) * 0.44);
      ray.quaternion.setFromAxisAngle(new THREE.Vector3(0, 1, 0), -angle);
      ray.rotateZ(-Math.PI / 2);
      haloGroup.add(ray);
    }
  } else if (type === 'queen') {
    // ARCHANGEL MICHAEL: Celestial Halo & Radiant Glowing Blade Aura
    const ringGeo = new THREE.TorusGeometry(0.30, 0.032, 16, 36);
    ringGeo.rotateX(Math.PI / 2);
    const ringMesh = new THREE.Mesh(ringGeo, goldHaloMat);
    ringMesh.position.set(0, 1.68, 0);
    haloGroup.add(ringMesh);

    const auraGeo = new THREE.RingGeometry(0.06, 0.32, 32);
    auraGeo.rotateX(Math.PI / 2);
    const auraMesh = new THREE.Mesh(auraGeo, holyGlowMat);
    auraMesh.position.set(0, 1.675, 0);
    haloGroup.add(auraMesh);
  } else if (type === 'bishop') {
    // SERAPHIM: Winged Angelic Halo
    const ringGeo = new THREE.TorusGeometry(0.24, 0.028, 16, 32);
    ringGeo.rotateX(Math.PI / 2);
    const ringMesh = new THREE.Mesh(ringGeo, goldHaloMat);
    ringMesh.position.set(0, 1.54, 0);
    haloGroup.add(ringMesh);
  } else if (type === 'knight') {
    // CELESTIAL PEGASUS: Golden Wing Crest
    const wingGeo = new THREE.ConeGeometry(0.045, 0.28, 8);
    for (const sign of [-1, 1]) {
      const w = new THREE.Mesh(wingGeo, goldHaloMat);
      w.position.set(sign * 0.18, 1.35, 0.05);
      w.rotateZ(sign * 0.45);
      haloGroup.add(w);
    }
  } else if (type === 'rook') {
    // CITADEL OF HEAVEN: Radiant Spire Finial
    const finialGeo = new THREE.OctahedronGeometry(0.10, 0);
    const finial = new THREE.Mesh(finialGeo, goldHaloMat);
    finial.position.set(0, 1.38, 0);
    haloGroup.add(finial);
  } else {
    // CHERUB GUARDIAN PAWNS: Subtle Golden Halo
    const ringGeo = new THREE.TorusGeometry(0.18, 0.022, 12, 28);
    ringGeo.rotateX(Math.PI / 2);
    const ringMesh = new THREE.Mesh(ringGeo, goldHaloMat);
    ringMesh.position.set(0, 1.15, 0);
    haloGroup.add(ringMesh);
  }

  pieceRoot.add(haloGroup);
}

/**
 * Attaches curved demonic horns, magma eyes, and infernal crests to The Devil and Hell's Horde
 */
export function attachDemonicAdornment(pieceRoot, type) {
  if (!pieceRoot) return;

  const demonGroup = new THREE.Group();
  demonGroup.name = 'demonic_adornment';

  const obsidianHornMat = new THREE.MeshStandardMaterial({
    color: 0x140e0e,
    emissive: 0x5c0e08,
    emissiveIntensity: 0.65,
    roughness: 0.22,
    metalness: 0.45
  });

  const magmaGlowMat = new THREE.MeshStandardMaterial({
    color: 0xff3b00,
    emissive: 0xff4500,
    emissiveIntensity: 1.85,
    roughness: 0.15,
    metalness: 0.2
  });

  function createCurvedHorn(hornLength = 0.42, baseRadius = 0.065, curveDir = 1) {
    const hornSegments = 6;
    const horn = new THREE.Group();
    for (let i = 0; i < hornSegments; i++) {
      const u = i / hornSegments;
      const segH = hornLength / hornSegments;
      const rTop = baseRadius * (1 - (i + 1) / hornSegments);
      const rBot = baseRadius * (1 - i / hornSegments);
      const segGeo = new THREE.CylinderGeometry(Math.max(0.005, rTop), rBot, segH, 10);
      const m = i === hornSegments - 1 ? magmaGlowMat : obsidianHornMat;
      const segMesh = new THREE.Mesh(segGeo, m);
      segMesh.position.set(
        curveDir * Math.pow(u, 1.8) * 0.16,
        i * segH * 0.92,
        Math.pow(u, 1.4) * -0.06
      );
      segMesh.rotation.z = curveDir * u * 0.55;
      horn.add(segMesh);
    }
    return horn;
  }

  if (type === 'king') {
    // THE DEVIL / LUCIFER: Twin Majestic Curved Demonic Horns & Burning Brimstone Crown
    for (const sign of [-1, 1]) {
      const horn = createCurvedHorn(0.56, 0.085, sign);
      horn.position.set(sign * 0.22, 1.58, 0.04);
      horn.rotation.z = sign * 0.28;
      horn.rotation.x = -0.15;
      demonGroup.add(horn);

      // Glowing Brimstone Eye
      const eyeGeo = new THREE.SphereGeometry(0.026, 8, 8);
      const eyeMesh = new THREE.Mesh(eyeGeo, magmaGlowMat);
      eyeMesh.position.set(sign * 0.08, 1.46, 0.18);
      demonGroup.add(eyeMesh);
    }
  } else if (type === 'queen') {
    // LILITH / DEMON QUEEN: Sweeping Curved Obsidian Horns
    for (const sign of [-1, 1]) {
      const horn = createCurvedHorn(0.44, 0.07, sign);
      horn.position.set(sign * 0.18, 1.48, 0.02);
      horn.rotation.z = sign * 0.32;
      demonGroup.add(horn);
    }
  } else if (type === 'bishop') {
    // ARCH-DEMON: Ram Horns Curling Outward
    for (const sign of [-1, 1]) {
      const horn = createCurvedHorn(0.36, 0.06, sign);
      horn.position.set(sign * 0.16, 1.38, 0.02);
      horn.rotation.z = sign * 0.45;
      horn.rotation.y = sign * 0.35;
      demonGroup.add(horn);
    }
  } else if (type === 'knight') {
    // NIGHTMARE STEED: Spiked Volcanic Horn & Ridge
    const horn = createCurvedHorn(0.32, 0.055, 0);
    horn.position.set(0, 1.34, 0.12);
    horn.rotation.x = 0.42;
    demonGroup.add(horn);
  } else if (type === 'rook') {
    // PANDEMONIUM TOWER: 4 Flaming Magma Horn Crests
    for (const [x, z] of [[-0.12, -0.12], [0.12, -0.12], [-0.12, 0.12], [0.12, 0.12]]) {
      const spikeGeo = new THREE.ConeGeometry(0.035, 0.18, 6);
      const spike = new THREE.Mesh(spikeGeo, magmaGlowMat);
      spike.position.set(x, 1.32, z);
      demonGroup.add(spike);
    }
  } else {
    // BRIMSTONE IMP PAWNS: Twin Curved Imp Horns
    for (const sign of [-1, 1]) {
      const horn = createCurvedHorn(0.24, 0.045, sign);
      horn.position.set(sign * 0.12, 1.05, 0.02);
      horn.rotation.z = sign * 0.35;
      demonGroup.add(horn);
    }
  }

  pieceRoot.add(demonGroup);
}

// =============================================================================
// Central Dimensional Rift & Particle Systems (Heaven Golden Sparks & Hellfire Embers)
// =============================================================================

export function setupHeavenHellEnvironment(scene, renderer) {
  const maxAniso = renderer?.capabilities?.getMaxAnisotropy() || 8;

  // 1. Grand Sistine Chapel Ceiling Barrel Vault (Curved over the nave)
  const sistineTex = createSistineCeilingTexture(maxAniso);
  const vaultRadius = 6.8;
  const vaultGeo = new THREE.CylinderGeometry(vaultRadius, vaultRadius, 36.0, 48, 1, true, -Math.PI * 0.48, Math.PI * 0.96);
  vaultGeo.rotateZ(Math.PI / 2);
  const vaultMat = new THREE.MeshStandardMaterial({
    map: sistineTex,
    roughness: 0.82,
    metalness: 0.04,
    side: THREE.BackSide
  });
  const vaultMesh = new THREE.Mesh(vaultGeo, vaultMat);
  vaultMesh.position.set(0, 5.75, 0);
  vaultMesh.receiveShadow = false;
  scene.add(vaultMesh);

  // 2. Altar Wall: "The Last Judgment" (Michelangelo) at South end wall (z = -18.0)
  const judgmentTex = createLastJudgmentTexture(maxAniso);
  const judgmentGeo = new THREE.PlaneGeometry(12.5, 9.2);
  const judgmentMat = new THREE.MeshStandardMaterial({
    map: judgmentTex,
    roughness: 0.84,
    metalness: 0.02
  });
  const judgmentMesh = new THREE.Mesh(judgmentGeo, judgmentMat);
  judgmentMesh.position.set(0, 4.85, -18.02);
  judgmentMesh.receiveShadow = false;
  scene.add(judgmentMesh);

  // 3. Central Dimensional Rift Line (between ranks 4 & 5 at z = 0, y = 0.776)
  const riftGeo = new THREE.PlaneGeometry(3.2, 0.045);
  riftGeo.rotateX(-Math.PI / 2);
  const riftMat = new THREE.MeshBasicMaterial({
    color: 0xffd166,
    transparent: true,
    opacity: 0.85,
    blending: THREE.AdditiveBlending
  });
  const riftMesh = new THREE.Mesh(riftGeo, riftMat);
  riftMesh.position.set(0, 0.778, 0);
  scene.add(riftMesh);

  // 4. Dual Particle Systems:
  // (a) Golden Divine Sacred Motes over Heaven's Half (z > 0)
  const heavenParticleCount = 120;
  const hPos = new Float32Array(heavenParticleCount * 3);
  const hVels = [];
  for (let i = 0; i < heavenParticleCount; i++) {
    hPos[i * 3] = (Math.random() - 0.5) * 3.2;
    hPos[i * 3 + 1] = 0.78 + Math.random() * 1.6;
    hPos[i * 3 + 2] = 0.15 + Math.random() * 1.55;
    hVels.push({ vy: 0.12 + Math.random() * 0.18, phase: Math.random() * Math.PI * 2 });
  }
  const hGeo = new THREE.BufferGeometry();
  hGeo.setAttribute('position', new THREE.BufferAttribute(hPos, 3));
  const hMat = new THREE.PointsMaterial({
    color: 0xf5d76e,
    size: 0.048,
    transparent: true,
    opacity: 0.75,
    blending: THREE.AdditiveBlending
  });
  const heavenPoints = new THREE.Points(hGeo, hMat);
  scene.add(heavenPoints);

  // (b) Crimson Brimstone Hellfire Embers over Hell's Half (z < 0)
  const hellParticleCount = 140;
  const fPos = new Float32Array(hellParticleCount * 3);
  const fVels = [];
  for (let i = 0; i < hellParticleCount; i++) {
    fPos[i * 3] = (Math.random() - 0.5) * 3.2;
    fPos[i * 3 + 1] = 0.78 + Math.random() * 1.6;
    fPos[i * 3 + 2] = -0.15 - Math.random() * 1.55;
    fVels.push({ vy: 0.18 + Math.random() * 0.28, phase: Math.random() * Math.PI * 2 });
  }
  const fGeo = new THREE.BufferGeometry();
  fGeo.setAttribute('position', new THREE.BufferAttribute(fPos, 3));
  const fMat = new THREE.PointsMaterial({
    color: 0xff3b00,
    size: 0.052,
    transparent: true,
    opacity: 0.82,
    blending: THREE.AdditiveBlending
  });
  const hellPoints = new THREE.Points(fGeo, fMat);
  scene.add(hellPoints);

  return {
    vaultMesh,
    judgmentMesh,
    riftMesh,
    updateParticles: (dt, time) => {
      // Animate Heaven Divine Motes
      const hp = heavenPoints.geometry.attributes.position;
      for (let i = 0; i < heavenParticleCount; i++) {
        let y = hp.getY(i) + hVels[i].vy * dt;
        if (y > 2.45) y = 0.78;
        hp.setY(i, y);
        hp.setX(i, hp.getX(i) + Math.sin(time * 2 + hVels[i].phase) * 0.002);
      }
      hp.needsUpdate = true;

      // Animate Hellfire Embers
      const fp = hellPoints.geometry.attributes.position;
      for (let i = 0; i < hellParticleCount; i++) {
        let y = fp.getY(i) + fVels[i].vy * dt;
        if (y > 2.55) y = 0.78;
        fp.setY(i, y);
        fp.setX(i, fp.getX(i) + Math.cos(time * 3 + fVels[i].phase) * 0.0035);
      }
      fp.needsUpdate = true;

      // Animate Central Dimensional Rift Pulse
      const riftPulse = 0.75 + 0.25 * Math.sin(time * 4.5);
      riftMat.opacity = riftPulse;
    }
  };
}

// =============================================================================
// Procedural Web Audio API Synthesizer (Gregorian Chants, Hellfire, Smites & Winner Swaps)
// =============================================================================

export class SistineAudioEngine {
  constructor() {
    this.ctx = null;
    this.isMuted = false;
    this.initialized = false;
  }

  ensureContext() {
    if (this.ctx) {
      if (this.ctx.state === 'suspended') {
        this.ctx.resume().catch(() => {});
      }
      return this.ctx;
    }
    const AudioContextClass = window.AudioContext || window.webkitAudioContext;
    if (AudioContextClass) {
      this.ctx = new AudioContextClass();
      this.initialized = true;
    }
    return this.ctx;
  }

  toggleMute() {
    this.isMuted = !this.isMuted;
    return this.isMuted;
  }

  // Heavenly Gregorian Chant Choir (Polyphonic Formant Synthesizer)
  playHeavenlyChant() {
    if (this.isMuted) return;
    const ctx = this.ensureContext();
    if (!ctx) return;

    const t = ctx.currentTime;
    const masterGain = ctx.createGain();
    masterGain.gain.setValueAtTime(0.001, t);
    masterGain.gain.linearRampToValueAtTime(0.22, t + 0.18);
    masterGain.gain.exponentialRampToValueAtTime(0.001, t + 1.85);
    masterGain.connect(ctx.destination);

    // Sacred Triad Chord: D4 (293.7 Hz), F#4 (370 Hz), A4 (440 Hz)
    const chordFreqs = [220, 293.7, 370, 440, 587.3];
    for (const freq of chordFreqs) {
      const osc = ctx.createOscillator();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, t);

      // Choir Formant Bandpass filter (Aah vowel at 800Hz / 1200Hz)
      const formant = ctx.createBiquadFilter();
      formant.type = 'bandpass';
      formant.frequency.value = 850;
      formant.Q.value = 3.5;

      osc.connect(formant);
      formant.connect(masterGain);

      osc.start(t);
      osc.stop(t + 1.9);
    }
  }

  // Infernal Subterranean Drone & Demonic Horn (Low Frequency Sawtooth + Distortion)
  playInfernalDrone() {
    if (this.isMuted) return;
    const ctx = this.ensureContext();
    if (!ctx) return;

    const t = ctx.currentTime;
    const masterGain = ctx.createGain();
    masterGain.gain.setValueAtTime(0.001, t);
    masterGain.gain.linearRampToValueAtTime(0.26, t + 0.12);
    masterGain.gain.exponentialRampToValueAtTime(0.001, t + 1.75);
    masterGain.connect(ctx.destination);

    // Deep Sub-Bass D1 (36.7 Hz) + D2 (73.4 Hz) with detune
    for (const freq of [55, 73.4, 110]) {
      const osc = ctx.createOscillator();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(freq, t);
      osc.detune.setValueAtTime((Math.random() - 0.5) * 24, t);

      const lpf = ctx.createBiquadFilter();
      lpf.type = 'lowpass';
      lpf.frequency.setValueAtTime(320, t);
      lpf.frequency.exponentialRampToValueAtTime(80, t + 1.6);

      osc.connect(lpf);
      lpf.connect(masterGain);

      osc.start(t);
      osc.stop(t + 1.8);
    }
  }

  // Combat Smite (Divine Holy Smite vs Infernal Brimstone Blast)
  playCombatSmite(isHeavenAttacker = true) {
    if (this.isMuted) return;
    const ctx = this.ensureContext();
    if (!ctx) return;

    const t = ctx.currentTime;

    // Heavy Stone Impact / Explosive Punch
    const punchOsc = ctx.createOscillator();
    const punchGain = ctx.createGain();
    punchOsc.type = 'sine';
    punchOsc.frequency.setValueAtTime(isHeavenAttacker ? 180 : 120, t);
    punchOsc.frequency.exponentialRampToValueAtTime(25, t + 0.45);
    punchGain.gain.setValueAtTime(0.55, t);
    punchGain.gain.exponentialRampToValueAtTime(0.001, t + 0.55);
    punchOsc.connect(punchGain);
    punchGain.connect(ctx.destination);
    punchOsc.start(t);
    punchOsc.stop(t + 0.6);

    if (isHeavenAttacker) {
      // Radiant Angelic Chime & Holy Thunder
      const chimeFreqs = [880, 1320, 1760];
      for (const f of chimeFreqs) {
        const cOsc = ctx.createOscillator();
        const cGain = ctx.createGain();
        cOsc.type = 'triangle';
        cOsc.frequency.setValueAtTime(f, t);
        cGain.gain.setValueAtTime(0.18, t);
        cGain.gain.exponentialRampToValueAtTime(0.001, t + 1.2);
        cOsc.connect(cGain);
        cGain.connect(ctx.destination);
        cOsc.start(t);
        cOsc.stop(t + 1.3);
      }
    } else {
      // Subterranean Magma Rumble & Demonic Crunch
      const noiseNode = ctx.createBufferSource();
      const bSize = ctx.sampleRate * 0.6;
      const b = ctx.createBuffer(1, bSize, ctx.sampleRate);
      const data = b.getChannelData(0);
      for (let i = 0; i < bSize; i++) {
        data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (bSize * 0.35));
      }
      noiseNode.buffer = b;
      const bpf = ctx.createBiquadFilter();
      bpf.type = 'bandpass';
      bpf.frequency.value = 240;
      bpf.Q.value = 2.2;
      const nGain = ctx.createGain();
      nGain.gain.setValueAtTime(0.42, t);
      nGain.gain.exponentialRampToValueAtTime(0.001, t + 0.65);
      noiseNode.connect(bpf);
      bpf.connect(nGain);
      nGain.connect(ctx.destination);
      noiseNode.start(t);
    }
  }

  // Grand Checkmate Fanfare (Heaven's Trumpets of Judgment vs Hell's Roar)
  playVictoryFanfare(winnerColor = 'w') {
    if (this.isMuted) return;
    const ctx = this.ensureContext();
    if (!ctx) return;

    const t = ctx.currentTime;
    const isGodWin = winnerColor === 'w';

    if (isGodWin) {
      // Glorious Trumpets of Judgment: Fanfare Arpeggio C5 -> E5 -> G5 -> C6
      const notes = [
        { f: 523.25, time: 0.0, dur: 0.35 },
        { f: 659.25, time: 0.3, dur: 0.35 },
        { f: 783.99, time: 0.6, dur: 0.45 },
        { f: 1046.50, time: 1.0, dur: 1.80 }
      ];
      for (const n of notes) {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(n.f, t + n.time);
        gain.gain.setValueAtTime(0.001, t + n.time);
        gain.gain.linearRampToValueAtTime(0.24, t + n.time + 0.06);
        gain.gain.exponentialRampToValueAtTime(0.001, t + n.time + n.dur);
        const lpf = ctx.createBiquadFilter();
        lpf.type = 'lowpass';
        lpf.frequency.value = 2400;
        osc.connect(lpf);
        lpf.connect(gain);
        gain.connect(ctx.destination);
        osc.start(t + n.time);
        osc.stop(t + n.time + n.dur + 0.1);
      }
    } else {
      // Apocalyptic Infernal Roar
      const droneOsc = ctx.createOscillator();
      const droneGain = ctx.createGain();
      droneOsc.type = 'sawtooth';
      droneOsc.frequency.setValueAtTime(82.4, t);
      droneOsc.frequency.exponentialRampToValueAtTime(45.0, t + 2.4);
      droneGain.gain.setValueAtTime(0.001, t);
      droneGain.gain.linearRampToValueAtTime(0.38, t + 0.15);
      droneGain.gain.exponentialRampToValueAtTime(0.001, t + 2.8);
      droneOsc.connect(droneGain);
      droneGain.connect(ctx.destination);
      droneOsc.start(t);
      droneOsc.stop(t + 2.9);
    }
  }

  // Dimensional Inversion / Winner Swaps Whoosh Sound
  playSwapRealmsSound() {
    if (this.isMuted) return;
    const ctx = this.ensureContext();
    if (!ctx) return;

    const t = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(140, t);
    osc.frequency.exponentialRampToValueAtTime(880, t + 0.6);
    osc.frequency.exponentialRampToValueAtTime(220, t + 1.2);

    gain.gain.setValueAtTime(0.001, t);
    gain.gain.linearRampToValueAtTime(0.32, t + 0.4);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 1.35);

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(t);
    osc.stop(t + 1.4);
  }
}
